import SwiftUI

struct Seed: Equatable {
    var h: Double
    var s: Double
}

func hsl(_ h: Double, _ s: Double, _ l: Double) -> Color {
    let hh = h - floor(h)
    let c = (1 - abs(2 * l - 1)) * s
    let x = c * (1 - abs((hh * 6).truncatingRemainder(dividingBy: 2) - 1))
    let m = l - c / 2
    var r = 0.0
    var g = 0.0
    var b = 0.0
    switch Int(hh * 6) {
    case 0: r = c; g = x
    case 1: r = x; g = c
    case 2: g = c; b = x
    case 3: g = x; b = c
    case 4: r = x; b = c
    default: r = c; b = x
    }
    return Color(red: r + m, green: g + m, blue: b + m)
}

/// Палитра в духе Material You (Material 3): цвета строятся от одного "семени" тона.
struct MD3Scheme {
    var primary: Color
    var onPrimary: Color
    var primaryContainer: Color
    var onPrimaryContainer: Color
    var secondary: Color
    var secondaryContainer: Color
    var onSecondaryContainer: Color
    var tertiaryContainer: Color
    var onTertiaryContainer: Color
    var surface: Color
    var surfaceContainer: Color
    var surfaceContainerHigh: Color
    var surfaceContainerHighest: Color
    var onSurface: Color
    var onSurfaceVariant: Color
    var outline: Color
    var outlineVariant: Color

    static func make(h: Double, s: Double, dark: Bool) -> MD3Scheme {
        let sp = min(max(s, 0.35), 0.75)
        let t = h + 0.17
        if dark {
            return MD3Scheme(
                primary: hsl(h, sp, 0.78),
                onPrimary: hsl(h, sp, 0.16),
                primaryContainer: hsl(h, sp * 0.8, 0.28),
                onPrimaryContainer: hsl(h, sp, 0.90),
                secondary: hsl(h, sp * 0.45, 0.78),
                secondaryContainer: hsl(h, sp * 0.35, 0.26),
                onSecondaryContainer: hsl(h, sp * 0.5, 0.88),
                tertiaryContainer: hsl(t, sp * 0.4, 0.27),
                onTertiaryContainer: hsl(t, sp * 0.5, 0.88),
                surface: hsl(h, 0.14, 0.09),
                surfaceContainer: hsl(h, 0.14, 0.13),
                surfaceContainerHigh: hsl(h, 0.14, 0.17),
                surfaceContainerHighest: hsl(h, 0.14, 0.21),
                onSurface: hsl(h, 0.12, 0.90),
                onSurfaceVariant: hsl(h, 0.10, 0.78),
                outline: hsl(h, 0.06, 0.58),
                outlineVariant: hsl(h, 0.10, 0.28)
            )
        }
        return MD3Scheme(
            primary: hsl(h, sp, 0.40),
            onPrimary: Color.white,
            primaryContainer: hsl(h, sp * 0.9, 0.90),
            onPrimaryContainer: hsl(h, sp, 0.12),
            secondary: hsl(h, sp * 0.35, 0.40),
            secondaryContainer: hsl(h, sp * 0.45, 0.89),
            onSecondaryContainer: hsl(h, sp * 0.5, 0.15),
            tertiaryContainer: hsl(t, sp * 0.5, 0.88),
            onTertiaryContainer: hsl(t, sp * 0.6, 0.14),
            surface: hsl(h, 0.20, 0.97),
            surfaceContainer: hsl(h, 0.22, 0.94),
            surfaceContainerHigh: hsl(h, 0.22, 0.92),
            surfaceContainerHighest: hsl(h, 0.22, 0.90),
            onSurface: hsl(h, 0.10, 0.10),
            onSurfaceVariant: hsl(h, 0.12, 0.30),
            outline: hsl(h, 0.08, 0.48),
            outlineVariant: hsl(h, 0.15, 0.80)
        )
    }
}

private struct MD3Key: EnvironmentKey {
    static let defaultValue = MD3Scheme.make(h: 0.74, s: 0.55, dark: false)
}

extension EnvironmentValues {
    var md3: MD3Scheme {
        get { self[MD3Key.self] }
        set { self[MD3Key.self] = newValue }
    }
}

/// Выбирает главный цвет обложки (самый "насыщенный" тон), по нему строится тема.
func dominantSeed(_ image: UIImage) -> Seed? {
    guard let cg = image.cgImage else { return nil }
    let size = 24
    var pixels = [UInt8](repeating: 0, count: size * size * 4)
    let drawn: Bool = pixels.withUnsafeMutableBytes { buf in
        guard let ctx = CGContext(data: buf.baseAddress,
                                  width: size, height: size,
                                  bitsPerComponent: 8, bytesPerRow: size * 4,
                                  space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: size, height: size))
        return true
    }
    guard drawn else { return nil }

    var weights = [Double](repeating: 0, count: 36)
    var satSum = [Double](repeating: 0, count: 36)
    for i in 0..<(size * size) {
        let r = Double(pixels[i * 4]) / 255
        let g = Double(pixels[i * 4 + 1]) / 255
        let b = Double(pixels[i * 4 + 2]) / 255
        let mx = max(r, max(g, b))
        let mn = min(r, min(g, b))
        let d = mx - mn
        if mx < 0.12 { continue }
        let s = d / mx
        if s < 0.12 { continue }
        var h: Double
        if mx == r {
            h = ((g - b) / d).truncatingRemainder(dividingBy: 6)
        } else if mx == g {
            h = (b - r) / d + 2
        } else {
            h = (r - g) / d + 4
        }
        h /= 6
        if h < 0 { h += 1 }
        let bucket = min(35, Int(h * 36))
        let w = s * mx
        weights[bucket] += w
        satSum[bucket] += s * w
    }
    guard let best = weights.indices.max(by: { weights[$0] < weights[$1] }), weights[best] > 0.5 else { return nil }
    return Seed(h: (Double(best) + 0.5) / 36, s: satSum[best] / weights[best])
}
