import SwiftUI
import UniformTypeIdentifiers
import MediaPlayer
import WebKit

// MARK: Выбор файлов (системное окно показывается напрямую, без SwiftUI-sheet)

func topViewController() -> UIViewController? {
    let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
    let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
    let window = scene?.windows.first(where: { $0.isKeyWindow }) ?? scene?.windows.first
    var top = window?.rootViewController
    while let presented = top?.presentedViewController {
        top = presented
    }
    return top
}

final class FilePicker: NSObject, UIDocumentPickerDelegate {
    static let shared = FilePicker()
    private var onPick: (([URL]) -> Void)?

    func present(_ onPick: @escaping ([URL]) -> Void) {
        self.onPick = onPick
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.audio, .movie], asCopy: true)
        picker.allowsMultipleSelection = true
        picker.delegate = self
        topViewController()?.present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        let handler = onPick
        onPick = nil
        handler?(urls)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        onPick = nil
    }
}

// MARK: Справка (локальная страница www/index.html)

struct HelpWebView: UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView {
        let w = WKWebView(frame: .zero)
        w.isOpaque = false
        w.backgroundColor = .clear
        if let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "www") {
            w.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        return w
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct HelpSheet: View {
    @Environment(\.md3) private var c
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            c.surface.ignoresSafeArea()
            VStack(spacing: 0) {
                HStack {
                    Text("Справка")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(c.onSurface)
                    Spacer()
                    IconButton(system: "xmark", size: 40, filled: true) { dismiss() }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)
                HelpWebView()
            }
        }
    }
}

// MARK: Медиатека Apple Music

struct AppleMusicSheet: View {
    @EnvironmentObject var library: LibraryStore
    @Environment(\.md3) private var c
    @Environment(\.dismiss) private var dismiss
    @State private var status = MPMediaLibrary.authorizationStatus()
    @State private var songs: [AMSong] = []
    @State private var lists: [AMPlaylist] = []
    @State private var loading = false
    @State private var slow = false
    @State private var query = ""
    @State private var token = 0

    private var filtered: [AMSong] {
        let q = query.trimmingCharacters(in: .whitespaces)
        if q.isEmpty { return songs }
        return songs.filter {
            $0.title.localizedCaseInsensitiveContains(q) || $0.artist.localizedCaseInsensitiveContains(q)
        }
    }

    var body: some View {
        ZStack {
            c.surface.ignoresSafeArea()
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Text("Apple Music")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(c.onSurface)
                    Spacer()
                    IconButton(system: "xmark", size: 40, filled: true) { dismiss() }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)

                if status != .authorized {
                    permission
                } else {
                    content
                }
            }
        }
        .onAppear {
            guard status == .authorized else { return }
            if let cached = AppleMusicLibrary.cachedSongs {
                songs = cached
                lists = AppleMusicLibrary.cachedLists ?? []
                load(silent: true)
            } else {
                load(silent: false)
            }
        }
    }

    private var permission: some View {
        VStack(spacing: 16) {
            EmptyStateView(icon: "music.note.list",
                           title: "Нужен доступ к медиатеке",
                           text: "Voilo покажет песни из вашей медиатеки Apple Music, чтобы вы могли добавить их в плеер. Для треков из подписки нужна активная подписка Apple Music.")
            if status == .notDetermined {
                PillButton(title: "Разрешить доступ", icon: "lock.open") {
                    AppleMusicLibrary.request { st in
                        status = st
                        if st == .authorized { load(silent: false) }
                    }
                }
            } else {
                PillButton(title: "Открыть настройки", icon: "gearshape") {
                    if let url = URL(string: UIApplication.openSettingsURLString) {
                        UIApplication.shared.open(url)
                    }
                }
            }
            Spacer()
        }
    }

    @ViewBuilder private var content: some View {
        if loading && songs.isEmpty {
            VStack(spacing: 16) {
                Spacer()
                ProgressView()
                Text("Читаю медиатеку…")
                    .font(.system(size: 15))
                    .foregroundColor(c.onSurfaceVariant)
                if slow {
                    Text("Это занимает дольше обычного. У больших медиатек первое чтение может длиться до минуты.")
                        .font(.system(size: 13))
                        .foregroundColor(c.onSurfaceVariant)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                    PillButton(title: "Повторить", icon: "arrow.clockwise", tonal: true) { load(silent: false) }
                }
                Spacer()
            }
            .frame(maxWidth: .infinity)
        } else {
            list
        }
    }

    private var list: some View {
        let existing = Set(library.tracks.map { $0.id })
        let shown = filtered
        return ScrollView(showsIndicators: false) {
            LazyVStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 10) {
                    PillButton(title: "Добавить всё (\(songs.count))", icon: "plus") {
                        library.importApple(songs)
                    }
                    if loading { ProgressView() }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 14)

                if !lists.isEmpty {
                    Text("Плейлисты")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(c.onSurface)
                        .padding(.horizontal, 20)
                        .padding(.bottom, 8)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(lists) { p in
                                ChipButton(title: p.name, selected: false) {
                                    library.importApplePlaylist(p, all: songs)
                                }
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                    .padding(.bottom, 14)
                }

                Text("Песни")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(c.onSurface)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 8)
                SearchField(text: $query, placeholder: "Поиск в медиатеке")
                    .padding(.bottom, 8)

                if songs.isEmpty {
                    EmptyStateView(icon: "music.note",
                                   title: "Медиатека пуста",
                                   text: "В вашей медиатеке не нашлось песен.")
                }

                ForEach(shown) { s in
                    let added = existing.contains("am-\(s.id)")
                    HStack(spacing: 12) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(s.title)
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(c.onSurface)
                                .lineLimit(1)
                            Text(s.artist + (s.cloud ? " · iCloud" : ""))
                                .font(.system(size: 13))
                                .foregroundColor(c.onSurfaceVariant)
                                .lineLimit(1)
                        }
                        Spacer(minLength: 0)
                        if added {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 22))
                                .foregroundColor(c.primary)
                        } else {
                            IconButton(system: "plus", size: 38, filled: true) {
                                library.importApple([s])
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 6)
                }
            }
            .padding(.bottom, 30)
        }
    }

    private func load(silent: Bool) {
        token += 1
        let mine = token
        loading = true
        slow = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
            if mine == token && loading { slow = true }
        }
        AppleMusicLibrary.fetchAll { s, p in
            guard mine == token else { return }
            songs = s
            lists = p
            loading = false
        }
    }
}
