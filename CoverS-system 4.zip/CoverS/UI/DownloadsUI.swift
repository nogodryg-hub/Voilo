import SwiftUI
import AVKit

struct DownloadsStrip: View {
    @EnvironmentObject var downloads: DownloadManager
    @Environment(\.md3) private var c

    var body: some View {
        if !downloads.items.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Загрузки")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(c.onSurface)
                    Spacer()
                    Button("Очистить") { downloads.clearFinished() }
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(c.primary)
                }
                .padding(.horizontal, 20)
                ForEach(downloads.items.prefix(8)) { item in
                    DownloadCard(item: item)
                }
            }
            .padding(.bottom, 10)
        }
    }
}

struct DownloadCard: View {
    let item: DownloadManager.Item
    @EnvironmentObject var downloads: DownloadManager
    @Environment(\.md3) private var c

    private var statusText: String {
        switch item.state {
        case .running:
            return item.total > 0 ? "\(Int(item.progress * 100))%" : "Скачивание…"
        case .finished:
            return "Готово"
        case .failed(let m):
            return m
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Image(systemName: item.isVideo ? "film" : "music.note")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(c.primary)
                    .frame(width: 24)
                VStack(alignment: .leading, spacing: 2) {
                    Text(item.name)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(c.onSurface)
                        .lineLimit(1)
                    Text("\(item.format) · \(item.sizeText) · \(statusText)")
                        .font(.system(size: 12))
                        .foregroundColor(item.state == .finished ? c.primary : c.onSurfaceVariant)
                        .lineLimit(2)
                }
                Spacer(minLength: 0)
                switch item.state {
                case .running:
                    IconButton(system: "xmark", size: 34, filled: true) { downloads.cancel(item.id) }
                case .failed:
                    if item.url != nil {
                        IconButton(system: "arrow.clockwise", size: 34, filled: true) { downloads.retry(item.id) }
                    }
                    IconButton(system: "trash", size: 34) { downloads.dismiss(item.id) }
                case .finished:
                    IconButton(system: "xmark", size: 34) { downloads.dismiss(item.id) }
                }
            }
            if item.state == .running {
                ProgressView(value: item.total > 0 ? item.progress : nil)
                    .tint(c.primary)
            }
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(c.surfaceContainerHigh))
        .padding(.horizontal, 16)
    }
}

struct VideoItem: Identifiable {
    let url: URL
    var id: String { url.path }
}

/// Скачанные видео: открываются без интернета.
struct VideosSection: View {
    @EnvironmentObject var downloads: DownloadManager
    @EnvironmentObject var player: PlayerModel
    @Environment(\.md3) private var c
    @State private var expanded = false
    @State private var watching: VideoItem? = nil

    var body: some View {
        if !downloads.videos.isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { expanded.toggle() }
                } label: {
                    HStack {
                        Text("Видео (\(downloads.videos.count))")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(c.onSurface)
                        Spacer()
                        Image(systemName: expanded ? "chevron.up" : "chevron.down")
                            .foregroundColor(c.onSurfaceVariant)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 8)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                if expanded {
                    ForEach(downloads.videos, id: \.path) { url in
                        HStack(spacing: 12) {
                            Button {
                                player.pause()
                                watching = VideoItem(url: url)
                            } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: "play.rectangle.fill")
                                        .font(.system(size: 26))
                                        .foregroundColor(c.primary)
                                    Text(url.lastPathComponent)
                                        .font(.system(size: 15, weight: .semibold))
                                        .foregroundColor(c.onSurface)
                                        .lineLimit(1)
                                    Spacer(minLength: 0)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            IconButton(system: "trash", size: 38, filled: true) { downloads.deleteVideo(url) }
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 4)
                    }
                }
            }
            .padding(.bottom, 8)
            .fullScreenCover(item: $watching) { item in
                VideoScreen(url: item.url)
            }
        }
    }
}

struct VideoScreen: View {
    let url: URL
    @Environment(\.dismiss) private var dismiss
    @State private var avp: AVPlayer? = nil

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            if let avp = avp {
                VideoPlayer(player: avp).ignoresSafeArea()
            }
            Button { dismiss() } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 30))
                    .foregroundColor(.white)
                    .padding(16)
            }
        }
        .onAppear {
            let p = AVPlayer(url: url)
            avp = p
            p.play()
        }
        .onDisappear { avp?.pause() }
    }
}
