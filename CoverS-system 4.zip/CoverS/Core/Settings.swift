import SwiftUI

final class AppSettings: ObservableObject {
    static let presets: [(name: String, hue: Double)] = [
        ("Фиолетовый", 0.74), ("Индиго", 0.66), ("Синий", 0.60), ("Голубой", 0.54),
        ("Бирюзовый", 0.48), ("Зелёный", 0.36), ("Лайм", 0.24), ("Жёлтый", 0.13),
        ("Оранжевый", 0.07), ("Красный", 0.99), ("Розовый", 0.93), ("Пурпурный", 0.83)
    ]

    @Published var mode: Int { didSet { UserDefaults.standard.set(mode, forKey: "mode") } }
    @Published var dynamicColor: Bool { didSet { UserDefaults.standard.set(dynamicColor, forKey: "dyn") } }
    @Published var seedIndex: Int { didSet { UserDefaults.standard.set(seedIndex, forKey: "seed") } }
    @Published var liveActivity: Bool { didSet { UserDefaults.standard.set(liveActivity, forKey: "live") } }
    @Published var amoled: Bool { didSet { UserDefaults.standard.set(amoled, forKey: "amoled") } }
    @Published var jamendoKey: String { didSet { UserDefaults.standard.set(jamendoKey, forKey: "jamendo") } }

    init() {
        let d = UserDefaults.standard
        mode = d.integer(forKey: "mode")
        dynamicColor = d.object(forKey: "dyn") == nil ? true : d.bool(forKey: "dyn")
        seedIndex = d.integer(forKey: "seed")
        liveActivity = d.object(forKey: "live") == nil ? true : d.bool(forKey: "live")
        amoled = d.bool(forKey: "amoled")
        jamendoKey = d.string(forKey: "jamendo") ?? ""
    }

    var forcedScheme: ColorScheme? {
        switch mode {
        case 1: return .light
        case 2: return .dark
        default: return nil
        }
    }

    func isDark(system: ColorScheme) -> Bool {
        switch mode {
        case 1: return false
        case 2: return true
        default: return system == .dark
        }
    }

    func scheme(dark: Bool, seed: Seed?) -> MD3Scheme {
        var result: MD3Scheme
        if dynamicColor, let s = seed {
            result = MD3Scheme.make(h: s.h, s: s.s, dark: dark)
        } else {
            let i = min(max(seedIndex, 0), AppSettings.presets.count - 1)
            result = MD3Scheme.make(h: AppSettings.presets[i].hue, s: 0.55, dark: dark)
        }
        if dark && amoled {
            result.surface = Color.black
            result.surfaceContainer = Color(white: 0.07)
            result.surfaceContainerHigh = Color(white: 0.11)
            result.surfaceContainerHighest = Color(white: 0.15)
        }
        return result
    }
}
