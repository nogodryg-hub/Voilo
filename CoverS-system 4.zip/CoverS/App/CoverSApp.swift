import SwiftUI

@main
struct CoverSApp: App {
    @StateObject private var library = LibraryStore()
    @StateObject private var player = PlayerModel()
    @StateObject private var settings = AppSettings()
    @StateObject private var online = OnlineStore()
    @StateObject private var downloads = DownloadManager()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(library)
                .environmentObject(player)
                .environmentObject(settings)
                .environmentObject(online)
                .environmentObject(downloads)
                .onAppear {
                    player.attach(settings: settings)
                    downloads.attach(library: library)
                }
                .onChange(of: phase) { p in
                    if p == .active { library.scanDocumentsDrop() }
                }
        }
    }
}
