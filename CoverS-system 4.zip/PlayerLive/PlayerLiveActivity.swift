import SwiftUI
import WidgetKit
import ActivityKit
#if canImport(AppIntents)
import AppIntents
#endif

@available(iOS 16.1, *)
private func accent(_ hue: Double) -> Color {
    Color(hue: hue, saturation: 0.55, brightness: 0.95)
}

@available(iOS 16.1, *)
struct ArtTile: View {
    let hue: Double
    let size: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.3, style: .continuous)
                .fill(Color(hue: hue, saturation: 0.45, brightness: 0.55))
            Image(systemName: "music.note")
                .font(.system(size: size * 0.45, weight: .semibold))
                .foregroundColor(accent(hue))
        }
        .frame(width: size, height: size)
    }
}

@available(iOS 16.1, *)
struct ProgressLine: View {
    let state: PlayerAttributes.ContentState

    var body: some View {
        let tint = accent(state.hue)
        if state.isPlaying && state.duration > 1 {
            let start = state.updatedAt.addingTimeInterval(-state.position)
            let end = start.addingTimeInterval(state.duration)
            ProgressView(timerInterval: start...end, countsDown: false) {
                EmptyView()
            } currentValueLabel: {
                EmptyView()
            }
            .tint(tint)
        } else {
            ProgressView(value: min(state.position, max(state.duration, 1)), total: max(state.duration, 1))
                .tint(tint)
        }
    }
}

@available(iOS 16.1, *)
struct IslandControls: View {
    let state: PlayerAttributes.ContentState

    var body: some View {
        if #available(iOS 17.0, *) {
            HStack(spacing: 34) {
                Button(intent: SonoraPrevIntent()) {
                    Image(systemName: "backward.fill")
                }
                Button(intent: SonoraToggleIntent()) {
                    Image(systemName: state.isPlaying ? "pause.fill" : "play.fill")
                }
                Button(intent: SonoraNextIntent()) {
                    Image(systemName: "forward.fill")
                }
            }
            .buttonStyle(.plain)
            .font(.system(size: 20, weight: .semibold))
            .foregroundColor(.white)
        } else {
            EmptyView()
        }
    }
}

@available(iOS 16.1, *)
struct LockScreenPlayerView: View {
    let state: PlayerAttributes.ContentState

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 12) {
                ArtTile(hue: state.hue, size: 54)
                VStack(alignment: .leading, spacing: 2) {
                    Text(state.title)
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(.white)
                        .lineLimit(1)
                    Text(state.artist)
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.7))
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
                Image(systemName: state.isPlaying ? "waveform" : "pause.fill")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(accent(state.hue))
            }
            ProgressLine(state: state)
            IslandControls(state: state)
        }
        .padding(16)
    }
}

@available(iOS 16.1, *)
struct PlayerLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PlayerAttributes.self) { context in
            LockScreenPlayerView(state: context.state)
                .activityBackgroundTint(Color(hue: context.state.hue, saturation: 0.5, brightness: 0.22))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    ArtTile(hue: context.state.hue, size: 52)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Image(systemName: context.state.isPlaying ? "waveform" : "pause.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(accent(context.state.hue))
                }
                DynamicIslandExpandedRegion(.center) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(context.state.title)
                            .font(.system(size: 16, weight: .semibold))
                            .lineLimit(1)
                        Text(context.state.artist)
                            .font(.system(size: 13))
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 10) {
                        ProgressLine(state: context.state)
                        IslandControls(state: context.state)
                    }
                    .padding(.top, 4)
                }
            } compactLeading: {
                Image(systemName: "music.note")
                    .foregroundColor(accent(context.state.hue))
            } compactTrailing: {
                Image(systemName: context.state.isPlaying ? "waveform" : "pause.fill")
                    .foregroundColor(accent(context.state.hue))
            } minimal: {
                Image(systemName: "music.note")
                    .foregroundColor(accent(context.state.hue))
            }
            .keylineTint(accent(context.state.hue))
        }
    }
}
