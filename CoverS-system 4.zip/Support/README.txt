Сюда XcodeGen кладёт Info.plist для приложения и виджета.
