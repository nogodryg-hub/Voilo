import Foundation
#if canImport(ActivityKit)
import ActivityKit
#endif
#if canImport(AppIntents)
import AppIntents
#endif

extension Notification.Name {
    static let sonoraToggle = Notification.Name("app.sonora.toggle")
    static let sonoraNext = Notification.Name("app.sonora.next")
    static let sonoraPrev = Notification.Name("app.sonora.prev")
}

#if canImport(ActivityKit)
@available(iOS 16.1, *)
struct PlayerAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var title: String
        var artist: String
        var isPlaying: Bool
        var position: Double
        var duration: Double
        var hue: Double
        var updatedAt: Date
    }

    var name: String
}
#endif

#if canImport(AppIntents)
@available(iOS 17.0, *)
struct SonoraToggleIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Play / Pause"

    func perform() async throws -> some IntentResult {
        NotificationCenter.default.post(name: .sonoraToggle, object: nil)
        return .result()
    }
}

@available(iOS 17.0, *)
struct SonoraNextIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Next"

    func perform() async throws -> some IntentResult {
        NotificationCenter.default.post(name: .sonoraNext, object: nil)
        return .result()
    }
}

@available(iOS 17.0, *)
struct SonoraPrevIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Previous"

    func perform() async throws -> some IntentResult {
        NotificationCenter.default.post(name: .sonoraPrev, object: nil)
        return .result()
    }
}
#endif
