import SwiftUI

struct SettingsCard<Content: View>: View {
    let title: String
    let content: Content
    @Environment(\.md3) private var c

    init(_ title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title)
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(c.primary)
            content
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(c.surfaceContainerHigh))
        .padding(.horizontal, 16)
    }
}

struct SettingsView: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var player: PlayerModel
    @Environment(\.md3) private var c
    var onAddFiles: () -> Void
    var onAddApple: () -> Void
    var onLink: () -> Void
    var onHelp: () -> Void

    private let modes = ["Системная", "Светлая", "Тёмная"]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                ScreenHeader(title: "Настройки")
                    .padding(.top, 20)
                    .padding(.bottom, 4)

                SettingsCard("ЦВЕТОВАЯ ТЕМА") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 4), spacing: 14) {
                        ThemeTile(title: "Из обложки", hue: nil, selected: settings.dynamicColor) {
                            settings.dynamicColor = true
                        }
                        ForEach(AppSettings.presets.indices, id: \.self) { i in
                            ThemeTile(title: AppSettings.presets[i].name,
                                      hue: AppSettings.presets[i].hue,
                                      selected: !settings.dynamicColor && settings.seedIndex == i) {
                                settings.seedIndex = i
                                settings.dynamicColor = false
                            }
                        }
                    }
                    Text(settings.dynamicColor
                         ? "Цвета меняются вместе с обложкой играющего трека."
                         : "Выбран постоянный цвет: " + AppSettings.presets[min(max(settings.seedIndex, 0), AppSettings.presets.count - 1)].name + ".")
                        .font(.system(size: 13))
                        .foregroundColor(c.onSurfaceVariant)
                }

                SettingsCard("РЕЖИМ") {
                    HStack(spacing: 8) {
                        ForEach(modes.indices, id: \.self) { i in
                            ChipButton(title: modes[i], selected: settings.mode == i) { settings.mode = i }
                        }
                    }
                    Toggle(isOn: $settings.amoled) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Чёрный фон (AMOLED)")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(c.onSurface)
                            Text("Для тёмного режима: глубокий чёрный вместо тёмно-цветного")
                                .font(.system(size: 13))
                                .foregroundColor(c.onSurfaceVariant)
                        }
                    }
                    .tint(c.primary)
                }

                SettingsCard("ВОСПРОИЗВЕДЕНИЕ") {
                    Toggle(isOn: $settings.liveActivity) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Плеер в острове")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(c.onSurface)
                            Text("Dynamic Island и экран блокировки (iOS 16.1+)")
                                .font(.system(size: 13))
                                .foregroundColor(c.onSurfaceVariant)
                        }
                    }
                    .tint(c.primary)

                    HStack {
                        Text("Таймер сна")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(c.onSurface)
                        Spacer()
                        Menu {
                            ForEach([15, 30, 45, 60], id: \.self) { m in
                                Button("\(m) минут") { player.setSleep(minutes: m) }
                            }
                            Button("Выключить") { player.setSleep(minutes: nil) }
                        } label: {
                            Text(player.sleepRemaining.map { formatTime(Double($0)) } ?? "Выкл.")
                                .font(.system(size: 14, weight: .semibold))
                                .padding(.horizontal, 14)
                                .frame(height: 36)
                                .background(Capsule().fill(c.secondaryContainer))
                                .foregroundColor(c.onSecondaryContainer)
                        }
                    }
                }

                SettingsCard("МУЗЫКА") {
                    HStack(spacing: 10) {
                        PillButton(title: "Из Файлов", icon: "folder", action: onAddFiles)
                        PillButton(title: "Apple Music", icon: "music.note.list", tonal: true, action: onAddApple)
                    }
                    PillButton(title: "По ссылке (файл или YouTube)", icon: "link", tonal: true, action: onLink)
                    Text("Файлы можно просто положить в папку Voilo в приложении «Файлы» (На iPhone → Voilo), они добавятся при следующем открытии.")
                        .font(.system(size: 13))
                        .foregroundColor(c.onSurfaceVariant)
                }

                SettingsCard("ОНЛАЙН-ИСТОЧНИКИ") {
                    Text("В подборках используются Audius, интернет-радио (каталог Radio Browser) и Jamendo (музыка Creative Commons).")
                        .font(.system(size: 13))
                        .foregroundColor(c.onSurfaceVariant)
                    TextField("Ключ Jamendo (client_id)", text: $settings.jamendoKey)
                        .disableAutocorrection(true)
                        .autocapitalization(.none)
                        .padding(.horizontal, 16)
                        .frame(height: 48)
                        .background(Capsule().fill(c.surfaceContainerHighest))
                        .foregroundColor(c.onSurface)
                    Text("Ключ бесплатный (developer.jamendo.com). С ним в подборках появляется музыка Jamendo, а у разрешённых треков можно скачать файл.")
                        .font(.system(size: 12))
                        .foregroundColor(c.onSurfaceVariant)
                }

                SettingsCard("О ПРИЛОЖЕНИИ") {
                    HStack {
                        Text("Треков в библиотеке")
                            .foregroundColor(c.onSurface)
                        Spacer()
                        Text("\(library.tracks.count)")
                            .foregroundColor(c.onSurfaceVariant)
                    }
                    .font(.system(size: 15))
                    PillButton(title: "Справка", icon: "questionmark.circle", tonal: true, action: onHelp)
                }
            }
            .padding(.bottom, 110)
        }
    }
}

struct ThemeTile: View {
    let title: String
    let hue: Double?
    let selected: Bool
    let action: () -> Void
    @Environment(\.md3) private var c

    var body: some View {
        Button(action: action) {
            VStack(spacing: 6) {
                ZStack {
                    if let hue = hue {
                        RoundedRectangle(cornerRadius: 22, style: .continuous).fill(hsl(hue, 0.45, 0.88))
                        Circle().fill(hsl(hue, 0.55, 0.42)).frame(width: 30, height: 30)
                            .offset(x: -9, y: -7)
                        Circle().fill(hsl(hue + 0.17, 0.5, 0.62)).frame(width: 18, height: 18)
                            .offset(x: 12, y: 11)
                    } else {
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .fill(AngularGradient(gradient: Gradient(colors: [
                                hsl(0.0, 0.6, 0.6), hsl(0.17, 0.6, 0.6), hsl(0.33, 0.6, 0.6),
                                hsl(0.5, 0.6, 0.6), hsl(0.67, 0.6, 0.6), hsl(0.83, 0.6, 0.6), hsl(1.0, 0.6, 0.6)
                            ]), center: .center))
                        Image(systemName: "sparkles")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundColor(.white)
                    }
                    if selected {
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .stroke(c.primary, lineWidth: 3)
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 20))
                            .foregroundColor(c.primary)
                            .background(Circle().fill(c.surfaceContainerHigh))
                            .offset(x: 20, y: -20)
                    }
                }
                .frame(height: 56)
                Text(title)
                    .font(.system(size: 11, weight: selected ? .bold : .medium))
                    .foregroundColor(selected ? c.onSurface : c.onSurfaceVariant)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
        }
        .buttonStyle(PressStyle())
    }
}
