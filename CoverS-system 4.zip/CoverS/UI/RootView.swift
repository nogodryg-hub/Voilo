import SwiftUI

enum ActiveSheet: String, Identifiable {
    case apple, help, newPlaylist, link
    var id: String { rawValue }
}

struct RootView: View {
    @EnvironmentObject var player: PlayerModel
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var downloads: DownloadManager
    @Environment(\.colorScheme) private var systemScheme

    @State private var tab = 0
    @State private var showNowPlaying = false
    @State private var sheet: ActiveSheet? = nil

    private let items = [
        NavItem(title: "Главная", icon: "house", iconFilled: "house.fill"),
        NavItem(title: "Песни", icon: "music.note", iconFilled: "music.note"),
        NavItem(title: "Онлайн", icon: "dot.radiowaves.left.and.right", iconFilled: "dot.radiowaves.left.and.right"),
        NavItem(title: "Плейлисты", icon: "music.note.list", iconFilled: "music.note.list"),
        NavItem(title: "Настройки", icon: "gearshape", iconFilled: "gearshape.fill")
    ]

    var body: some View {
        let dark = settings.isDark(system: systemScheme)
        let scheme = settings.scheme(dark: dark, seed: player.seed)
        ZStack {
            scheme.surface.ignoresSafeArea()
            content
        }
        .safeAreaInset(edge: .bottom, spacing: 0) { bottomBar }
        .overlay(alignment: .top) { toast }
        .environment(\.md3, scheme)
        .preferredColorScheme(settings.forcedScheme)
        .tint(scheme.primary)
        .fullScreenCover(isPresented: $showNowPlaying) {
            NowPlayingView()
                .environment(\.md3, scheme)
                .preferredColorScheme(settings.forcedScheme)
        }
        .sheet(item: $sheet) { s in
            sheetContent(s)
                .environment(\.md3, scheme)
                .preferredColorScheme(settings.forcedScheme)
        }
        .onChange(of: library.showNewPlaylist) { show in
            if show {
                library.showNewPlaylist = false
                sheet = .newPlaylist
            }
        }
        .onChange(of: player.current?.id) { id in
            if id == nil { showNowPlaying = false }
        }
        .onChange(of: library.message) { m in
            if m != nil {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) { library.message = nil }
            }
        }
        .onChange(of: player.banner) { m in
            if m != nil {
                DispatchQueue.main.asyncAfter(deadline: .now() + 3.2) { player.banner = nil }
            }
        }
        .onChange(of: settings.liveActivity) { _ in player.refreshLive() }
    }

    // MARK: Действия

    private func openFiles() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            FilePicker.shared.present { urls in downloads.importPicked(urls) }
        }
    }

    private func openApple() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { sheet = .apple }
    }

    private func openLink() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { sheet = .link }
    }

    private func openHelp() {
        sheet = .help
    }

    @ViewBuilder private func sheetContent(_ s: ActiveSheet) -> some View {
        switch s {
        case .apple: AppleMusicSheet()
        case .help: HelpSheet()
        case .newPlaylist: NewPlaylistSheet()
        case .link: LinkSheet()
        }
    }

    // MARK: Части экрана

    @ViewBuilder private var content: some View {
        switch tab {
        case 0:
            HomeView(onAddFiles: { openFiles() }, onAddApple: { openApple() })
        case 1:
            SongsView()
        case 2:
            OnlineView()
        case 3:
            PlaylistsView()
        default:
            SettingsView(onAddFiles: { openFiles() },
                         onAddApple: { openApple() },
                         onLink: { openLink() },
                         onHelp: { openHelp() })
        }
    }

    private var bottomBar: some View {
        VStack(spacing: 8) {
            if tab == 0 || tab == 1 {
                HStack {
                    Spacer()
                    Menu {
                        Button { openFiles() } label: { Label("Из Файлов", systemImage: "folder") }
                        Button { openApple() } label: { Label("Из Apple Music", systemImage: "music.note.list") }
                        Button { openLink() } label: { Label("По ссылке", systemImage: "link") }
                    } label: {
                        FABLabel(title: "Добавить", icon: "plus")
                    }
                    .padding(.trailing, 16)
                }
            }
            if player.current != nil {
                MiniPlayer()
                    .padding(.horizontal, 12)
                    .onTapGesture { showNowPlaying = true }
            }
            NavBar(selection: $tab, items: items)
        }
    }

    @ViewBuilder private var toast: some View {
        if let m = library.message ?? player.banner {
            ToastView(text: m)
                .padding(.top, 8)
                .transition(.move(edge: .top).combined(with: .opacity))
        }
    }
}
