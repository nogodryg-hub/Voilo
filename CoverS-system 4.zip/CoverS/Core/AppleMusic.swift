import Foundation
import MediaPlayer
import UIKit

/// Лёгкие копии данных из медиатеки: интерфейс работает только с ними и не трогает MPMediaItem.
struct AMSong: Identifiable, Hashable {
    let id: UInt64
    let title: String
    let artist: String
    let album: String
    let duration: Double
    let added: Date
    let cloud: Bool
}

struct AMPlaylist: Identifiable, Hashable {
    let id: UInt64
    let name: String
    let songIDs: [UInt64]
}

enum AppleMusicLibrary {
    private static var cache: [UInt64: MPMediaItem] = [:]
    private static let lock = NSLock()

    static var cachedSongs: [AMSong]?
    static var cachedLists: [AMPlaylist]?

    static var authorized: Bool {
        MPMediaLibrary.authorizationStatus() == .authorized
    }

    static func request(_ done: @escaping (MPMediaLibraryAuthorizationStatus) -> Void) {
        MPMediaLibrary.requestAuthorization { status in
            DispatchQueue.main.async { done(status) }
        }
    }

    /// Читает медиатеку в фоне и отдаёт результат в главном потоке.
    static func fetchAll(_ done: @escaping ([AMSong], [AMPlaylist]) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            let items = MPMediaQuery.songs().items ?? []

            lock.lock()
            for i in items { cache[i.persistentID] = i }
            lock.unlock()

            var songs: [AMSong] = []
            songs.reserveCapacity(items.count)
            for i in items {
                songs.append(AMSong(id: i.persistentID,
                                    title: i.title ?? "Без названия",
                                    artist: i.artist ?? "Неизвестный исполнитель",
                                    album: i.albumTitle ?? "",
                                    duration: i.playbackDuration,
                                    added: i.dateAdded,
                                    cloud: i.isCloudItem))
            }
            songs.sort { $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending }

            let lists = (MPMediaQuery.playlists().collections as? [MPMediaPlaylist]) ?? []
            let amLists = lists.map { p in
                AMPlaylist(id: p.persistentID,
                           name: p.name ?? "Плейлист",
                           songIDs: p.items.map { $0.persistentID })
            }

            DispatchQueue.main.async {
                cachedSongs = songs
                cachedLists = amLists
                done(songs, amLists)
            }
        }
    }

    /// Поиск трека по идентификатору (вызывать не из главного потока).
    static func item(_ pid: UInt64) -> MPMediaItem? {
        lock.lock()
        let hit = cache[pid]
        lock.unlock()
        if let hit = hit { return hit }

        let q = MPMediaQuery.songs()
        q.addFilterPredicate(MPMediaPropertyPredicate(value: NSNumber(value: pid),
                                                      forProperty: MPMediaItemPropertyPersistentID))
        guard let found = q.items?.first else { return nil }
        lock.lock()
        cache[pid] = found
        lock.unlock()
        return found
    }
}

enum ArtworkLoader {
    static let cache = NSCache<NSString, UIImage>()

    static func image(for track: Track, maxSide: CGFloat) -> UIImage? {
        let key = "\(track.id)-\(Int(maxSide))" as NSString
        if let hit = cache.object(forKey: key) { return hit }

        var img: UIImage?
        switch track.source {
        case .file:
            if track.hasArtwork {
                img = UIImage(contentsOfFile: Paths.artwork.appendingPathComponent(track.id + ".jpg").path)
            }
        case .apple(let pid):
            img = AppleMusicLibrary.item(pid)?.artwork?.image(at: CGSize(width: maxSide, height: maxSide))
        case .remote:
            if let s = track.artworkURL, let u = URL(string: s), let d = Net.fetchSync(u),
               let raw = UIImage(data: d) {
                img = raw.scaled(maxSide: 800)
            }
        }
        if let img = img { cache.setObject(img, forKey: key) }
        return img
    }
}
