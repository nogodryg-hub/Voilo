import SwiftUI

enum LinkState {
    case idle
    case loading
    case youtube(YouTubeLink, YTInfo)
    case failed(String)
}

struct LinkSheet: View {
    @EnvironmentObject var downloads: DownloadManager
    @EnvironmentObject var player: PlayerModel
    @Environment(\.md3) private var c
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var state: LinkState = .idle
    @State private var watching: YouTubeWatch? = nil
    @State private var note: String? = nil

    var body: some View {
        ZStack {
            c.surface.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text("Добавить по ссылке")
                            .font(.system(size: 26, weight: .bold))
                            .foregroundColor(c.onSurface)
                        Spacer()
                        IconButton(system: "xmark", size: 40, filled: true) { dismiss() }
                    }

                    TextField("Ссылка на файл или видео YouTube", text: $text)
                        .keyboardType(.URL)
                        .disableAutocorrection(true)
                        .autocapitalization(.none)
                        .padding(.horizontal, 18)
                        .frame(height: 52)
                        .background(Capsule().fill(c.surfaceContainerHigh))
                        .foregroundColor(c.onSurface)

                    HStack(spacing: 10) {
                        PillButton(title: "Добавить", icon: "plus") { process() }
                        PillButton(title: "Вставить", icon: "doc.on.clipboard", tonal: true) {
                            if let s = UIPasteboard.general.string {
                                text = s
                                process()
                            }
                        }
                    }

                    Text("Прямая ссылка на аудио или видео файл (mp3, m4a, flac, mp4…) скачивается сразу, без плеера, и попадает в библиотеку. Ссылка YouTube покажет информацию о ролике и откроет его в официальном плеере.")
                        .font(.system(size: 13))
                        .foregroundColor(c.onSurfaceVariant)

                    if let n = note {
                        Text(n)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(c.primary)
                    }

                    result

                    DownloadsStrip().padding(.horizontal, -16)
                }
                .padding(20)
            }
        }
        .fullScreenCover(item: $watching) { w in
            YouTubeScreen(url: w.url)
        }
    }

    @ViewBuilder private var result: some View {
        switch state {
        case .idle:
            EmptyView()
        case .loading:
            HStack(spacing: 12) {
                ProgressView()
                Text("Получаю информацию о видео…")
                    .font(.system(size: 14))
                    .foregroundColor(c.onSurfaceVariant)
            }
        case .failed(let m):
            Text(m)
                .font(.system(size: 14))
                .foregroundColor(c.onSurfaceVariant)
        case .youtube(let link, let info):
            VStack(alignment: .leading, spacing: 12) {
                if let t = info.thumbnail, let u = URL(string: t) {
                    AsyncImage(url: u) { img in
                        img.resizable().scaledToFill()
                    } placeholder: {
                        Rectangle().fill(c.primaryContainer)
                    }
                    .frame(height: 190)
                    .frame(maxWidth: .infinity)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                }
                Text(info.title)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(c.onSurface)
                    .lineLimit(3)
                if !info.author.isEmpty {
                    Text(info.author + (link.isPlaylist ? " · плейлист" : ""))
                        .font(.system(size: 14))
                        .foregroundColor(c.onSurfaceVariant)
                }
                PillButton(title: "Смотреть в плеере YouTube", icon: "play.fill") {
                    if let u = link.embedURL {
                        player.pause()
                        watching = YouTubeWatch(url: u)
                    }
                }
                Text("Скачивание с YouTube недоступно: правила платформы разрешают смотреть ролики только через официальный плеер. Если вам нужен файл, добавьте его с устройства или по прямой ссылке.")
                    .font(.system(size: 12))
                    .foregroundColor(c.onSurfaceVariant)
            }
            .padding(16)
            .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(c.surfaceContainerHigh))
        }
    }

    private func process() {
        let raw = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }
        note = nil

        if let yt = YouTubeLink.parse(raw) {
            state = .loading
            Task {
                let info = await YouTubeInfo.fetch(raw)
                await MainActor.run {
                    if let info = info {
                        state = .youtube(yt, info)
                    } else {
                        state = .failed("Не удалось получить информацию о видео. Оно может быть приватным или не разрешать встраивание.")
                    }
                }
            }
        } else if let u = URL(string: raw), let s = u.scheme?.lowercased(), s == "http" || s == "https" {
            downloads.start(raw)
            state = .idle
            text = ""
            note = "Скачивание запущено. Прогресс виден ниже и во вкладке «Песни»."
        } else {
            state = .failed("Это не похоже на ссылку. Вставьте адрес, который начинается с http:// или https://")
        }
    }
}
