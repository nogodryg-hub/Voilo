import Foundation
import UIKit

enum TrackSource: Codable, Hashable {
    case file(String)      // имя файла в Documents/Music
    case apple(UInt64)     // persistentID трека из медиатеки Apple Music
    case remote(String)    // потоковая ссылка (онлайн-подборки, радио)
}

struct Track: Identifiable, Codable, Hashable {
    var id: String
    var title: String
    var artist: String
    var album: String
    var duration: Double
    var source: TrackSource
    var addedAt: Date
    var hasArtwork: Bool
    var artworkURL: String? = nil
}

extension Track {
    /// Прямой эфир (радио): у потока нет длительности.
    var isLive: Bool {
        if case .remote = source { return duration <= 0 }
        return false
    }
}

struct Playlist: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var trackIDs: [String]
}

enum RepeatMode: Int {
    case off, all, one
}

enum SortMode: Int, CaseIterable {
    case recent, title, artist

    var title: String {
        switch self {
        case .recent: return "Недавние"
        case .title: return "По названию"
        case .artist: return "По исполнителю"
        }
    }
}

func formatTime(_ t: Double) -> String {
    guard t.isFinite, t >= 0 else { return "0:00" }
    let s = Int(t)
    let h = s / 3600
    let m = (s % 3600) / 60
    let sec = s % 60
    if h > 0 { return String(format: "%d:%02d:%02d", h, m, sec) }
    return String(format: "%d:%02d", m, sec)
}

extension UIImage {
    func scaled(maxSide: CGFloat) -> UIImage {
        let m = max(size.width, size.height)
        guard m > maxSide, m > 0 else { return self }
        let k = maxSide / m
        let newSize = CGSize(width: size.width * k, height: size.height * k)
        let renderer = UIGraphicsImageRenderer(size: newSize)
        return renderer.image { _ in
            self.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }
}
