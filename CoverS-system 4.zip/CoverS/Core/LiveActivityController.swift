import Foundation
#if canImport(ActivityKit)
import ActivityKit
#endif

/// Плеер в Dynamic Island и на экране блокировки (Live Activity).
/// Все обращения к системе идут в фоновой очереди, чтобы не тормозить интерфейс.
final class LiveActivityController {
    static let shared = LiveActivityController()
    private var box: Any?
    private let queue = DispatchQueue(label: "app.voilo.live")

    func sync(title: String, artist: String, isPlaying: Bool, position: Double, duration: Double, hue: Double) {
        #if canImport(ActivityKit)
        if #available(iOS 16.1, *) {
            let state = PlayerAttributes.ContentState(title: title, artist: artist, isPlaying: isPlaying,
                                                     position: position, duration: duration,
                                                     hue: hue, updatedAt: Date())
            queue.async { [weak self] in self?.push(state) }
        }
        #endif
    }

    func end() {
        #if canImport(ActivityKit)
        if #available(iOS 16.1, *) {
            queue.async { [weak self] in self?.finish() }
        }
        #endif
    }

    #if canImport(ActivityKit)
    @available(iOS 16.1, *)
    private func push(_ state: PlayerAttributes.ContentState) {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }

        if box == nil, let existing = Activity<PlayerAttributes>.activities.first {
            box = existing
        }

        if let act = box as? Activity<PlayerAttributes> {
            Task {
                if #available(iOS 16.2, *) {
                    await act.update(ActivityContent(state: state, staleDate: nil))
                } else {
                    await act.update(using: state)
                }
            }
            return
        }

        let attrs = PlayerAttributes(name: "player")
        do {
            if #available(iOS 16.2, *) {
                box = try Activity<PlayerAttributes>.request(attributes: attrs,
                                                             content: ActivityContent(state: state, staleDate: nil),
                                                             pushType: nil)
            } else {
                box = try Activity<PlayerAttributes>.request(attributes: attrs,
                                                             contentState: state,
                                                             pushType: nil)
            }
        } catch {
            print("[Voilo] Live Activity error: \(error)")
        }
    }

    @available(iOS 16.1, *)
    private func finish() {
        let current = (box as? Activity<PlayerAttributes>) ?? Activity<PlayerAttributes>.activities.first
        box = nil
        guard let act = current else { return }
        Task {
            if #available(iOS 16.2, *) {
                await act.end(nil, dismissalPolicy: .immediate)
            } else {
                await act.end(using: nil, dismissalPolicy: .immediate)
            }
        }
    }
    #endif
}
