import Foundation
import SwiftUI
import WebKit

/// Распознавание ссылок YouTube. Видео не скачивается: оно смотрится только через официальный встроенный плеер.
enum YouTubeLink {
    case video(String)
    case playlist(String)

    static func parse(_ text: String) -> YouTubeLink? {
        guard let u = URL(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              let host = u.host?.lowercased(),
              host == "youtu.be" || host.hasSuffix("youtube.com") || host.hasSuffix("youtube-nocookie.com") else { return nil }
        let items = URLComponents(url: u, resolvingAgainstBaseURL: false)?.queryItems ?? []
        func param(_ n: String) -> String? {
            items.first(where: { $0.name == n })?.value
        }
        let parts = u.pathComponents
        if host == "youtu.be" {
            if parts.count >= 2 { return YouTubeLink.video(parts[1]) }
            return nil
        }
        if let v = param("v"), !v.isEmpty { return YouTubeLink.video(v) }
        if parts.count >= 3, ["shorts", "embed", "live", "v"].contains(parts[1]) {
            return YouTubeLink.video(parts[2])
        }
        if let l = param("list"), !l.isEmpty { return YouTubeLink.playlist(l) }
        return nil
    }

    var embedURL: URL? {
        let ref = "https%3A%2F%2Fapp.sonora.player"
        switch self {
        case .video(let id):
            return URL(string: "https://www.youtube.com/embed/\(id)?playsinline=1&rel=0&widget_referrer=\(ref)")
        case .playlist(let id):
            return URL(string: "https://www.youtube.com/embed/videoseries?list=\(id)&playsinline=1&rel=0&widget_referrer=\(ref)")
        }
    }

    var isPlaylist: Bool {
        if case .playlist = self { return true }
        return false
    }
}

struct YTInfo {
    let title: String
    let author: String
    let thumbnail: String?
}

enum YouTubeInfo {
    /// Официальный публичный oEmbed YouTube: ключ и оплата не нужны.
    static func fetch(_ link: String) async -> YTInfo? {
        var c = URLComponents(string: "https://www.youtube.com/oembed")
        c?.queryItems = [URLQueryItem(name: "url", value: link.trimmingCharacters(in: .whitespacesAndNewlines)),
                         URLQueryItem(name: "format", value: "json")]
        guard let u = c?.url,
              let obj = await Net.json(u) as? [String: Any],
              let title = obj["title"] as? String else { return nil }
        return YTInfo(title: title,
                      author: (obj["author_name"] as? String) ?? "",
                      thumbnail: obj["thumbnail_url"] as? String)
    }
}

struct YouTubeWatch: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

struct YouTubeWebView: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        let w = WKWebView(frame: .zero, configuration: cfg)
        w.isOpaque = false
        w.backgroundColor = .black
        w.scrollView.backgroundColor = .black
        var req = URLRequest(url: url)
        req.setValue("https://app.sonora.player/", forHTTPHeaderField: "Referer")
        w.load(req)
        return w
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct YouTubeScreen: View {
    let url: URL
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            YouTubeWebView(url: url).ignoresSafeArea(edges: .bottom)
                .padding(.top, 56)
            Button { dismiss() } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 32))
                    .foregroundColor(.white)
                    .padding(14)
            }
        }
    }
}
