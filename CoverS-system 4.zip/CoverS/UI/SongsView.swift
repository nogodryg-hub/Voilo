import SwiftUI

struct SongsView: View {
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var player: PlayerModel
    @Environment(\.md3) private var c
    @State private var query = ""
    @State private var sort: SortMode = .recent

    private var filtered: [Track] {
        let base = library.sorted(sort)
        let q = query.trimmingCharacters(in: .whitespaces)
        if q.isEmpty { return base }
        return base.filter {
            $0.title.localizedCaseInsensitiveContains(q)
                || $0.artist.localizedCaseInsensitiveContains(q)
                || $0.album.localizedCaseInsensitiveContains(q)
        }
    }

    var body: some View {
        let list = filtered
        ScrollView(showsIndicators: false) {
            LazyVStack(alignment: .leading, spacing: 0) {
                ScreenHeader(title: "Песни", subtitle: "\(library.tracks.count) в библиотеке")
                    .padding(.top, 20)
                    .padding(.bottom, 14)
                SearchField(text: $query, placeholder: "Поиск по названию, исполнителю")
                    .padding(.bottom, 12)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(SortMode.allCases, id: \.rawValue) { m in
                            ChipButton(title: m.title, selected: sort == m) { sort = m }
                        }
                    }
                    .padding(.horizontal, 16)
                }
                .padding(.bottom, 10)

                DownloadsStrip()
                VideosSection()

                if !list.isEmpty {
                    HStack(spacing: 10) {
                        PillButton(title: "Играть", icon: "play.fill") { player.play(list, at: 0) }
                        PillButton(title: "Вперемешку", icon: "shuffle", tonal: true) { player.playShuffled(list) }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 10)
                }

                if list.isEmpty {
                    EmptyStateView(icon: "magnifyingglass",
                                   title: library.tracks.isEmpty ? "Библиотека пуста" : "Ничего не найдено",
                                   text: library.tracks.isEmpty ? "Нажмите «Добавить», чтобы загрузить песни." : "Попробуйте другой запрос.")
                } else {
                    ForEach(Array(list.enumerated()), id: \.element.id) { i, t in
                        SongRow(track: t) { player.play(list, at: i) }
                    }
                }
            }
            .padding(.bottom, 110)
        }
    }
}
