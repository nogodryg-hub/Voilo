import Foundation
import SwiftUI
import AVFoundation
import MediaPlayer
import UIKit

/// Позиция воспроизведения вынесена отдельно: она меняется 4 раза в секунду,
/// и не должна перерисовывать весь интерфейс.
final class PlaybackClock: ObservableObject {
    @Published var position: Double = 0
}

final class PlayerModel: ObservableObject {
    @Published private(set) var queue: [Track] = []
    @Published private(set) var index: Int = 0
    @Published private(set) var isPlaying = false
    @Published private(set) var duration: Double = 0
    @Published private(set) var shuffle = false
    @Published private(set) var repeatMode: RepeatMode = .off
    @Published private(set) var speed: Float = 1.0
    @Published private(set) var sleepRemaining: Int? = nil
    @Published private(set) var artwork: UIImage? = nil
    @Published private(set) var seed: Seed? = nil
    @Published var banner: String? = nil

    let clock = PlaybackClock()
    var position: Double {
        get { clock.position }
        set { clock.position = newValue }
    }
    var scrubbing = false

    var current: Track? {
        queue.indices.contains(index) ? queue[index] : nil
    }

    private var original: [Track] = []
    private let av = AVPlayer()
    private var ticker: Timer?
    private var sleepTimer: Timer?
    private var endObserver: NSObjectProtocol?
    private var statusObs: NSKeyValueObservation?
    private var appleMode = false
    private var applePlayer: MPMusicPlayerController = MPMusicPlayerController.applicationMusicPlayer
    private var appleCtx: (item: MPMediaItem, attempts: [(Bool, Bool)], index: Int, autoplay: Bool)?
    private var appleLoaded = false
    private var appleReady = false
    private var appleStart = Date()
    private var appleCommandAt = Date()
    private var applePeak: Double = 0
    private weak var settings: AppSettings?
    private var artTicket = 0
    private var loadTicket = 0

    init() {
        let nc = NotificationCenter.default
        nc.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] n in
            self?.handleInterruption(n)
        }
        nc.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main) { [weak self] n in
            self?.handleRoute(n)
        }
        nc.addObserver(forName: .sonoraToggle, object: nil, queue: .main) { [weak self] _ in self?.togglePlay() }
        nc.addObserver(forName: .sonoraNext, object: nil, queue: .main) { [weak self] _ in self?.next() }
        nc.addObserver(forName: .sonoraPrev, object: nil, queue: .main) { [weak self] _ in self?.previous() }

        configureRemote()
        let t = Timer(timeInterval: 0.25, repeats: true) { [weak self] _ in self?.tick() }
        RunLoop.main.add(t, forMode: .common)
        ticker = t
    }

    func attach(settings: AppSettings) {
        self.settings = settings
    }

    // MARK: Очередь и запуск

    func play(_ tracks: [Track], at start: Int = 0) {
        guard tracks.indices.contains(start) else { return }
        original = tracks
        if shuffle {
            var rest = tracks
            let first = rest.remove(at: start)
            rest.shuffle()
            queue = [first] + rest
            index = 0
        } else {
            queue = tracks
            index = start
        }
        load(autoplay: true)
    }

    func playShuffled(_ tracks: [Track]) {
        guard let start = tracks.indices.randomElement() else { return }
        shuffle = true
        play(tracks, at: start)
    }

    func jump(to i: Int) {
        guard queue.indices.contains(i) else { return }
        index = i
        load(autoplay: true)
    }

    func playNext(_ t: Track) {
        guard current != nil else { play([t]); return }
        queue.insert(t, at: index + 1)
        original.append(t)
        banner = "Сыграет следующим"
    }

    func addToQueue(_ t: Track) {
        guard current != nil else { play([t]); return }
        queue.append(t)
        original.append(t)
        banner = "Добавлено в очередь"
    }

    func removeFromQueue(at i: Int) {
        guard queue.indices.contains(i), i != index else { return }
        queue.remove(at: i)
        if i < index { index -= 1 }
    }

    /// Вызывается, когда треки удалены из медиатеки.
    func remove(trackIDs: Set<String>) {
        guard !trackIDs.isEmpty else { return }
        let currentID = current?.id
        original.removeAll { trackIDs.contains($0.id) }
        if let cid = currentID, trackIDs.contains(cid) {
            let rest = queue.filter { !trackIDs.contains($0.id) }
            let upcoming = queue.dropFirst(index + 1).filter { !trackIDs.contains($0.id) }
            if rest.isEmpty {
                stopAll()
            } else {
                queue = rest
                index = min(rest.count - upcoming.count, rest.count - 1)
                load(autoplay: isPlaying)
            }
        } else {
            queue.removeAll { trackIDs.contains($0.id) }
            if let cid = currentID, let i = queue.firstIndex(where: { $0.id == cid }) { index = i }
        }
    }

    func setShuffle(_ on: Bool) {
        shuffle = on
        guard let cur = current else { return }
        if on {
            var rest = queue
            rest.remove(at: index)
            rest.shuffle()
            queue = [cur] + rest
            index = 0
        } else {
            if !original.isEmpty { queue = original }
            index = queue.firstIndex(where: { $0.id == cur.id }) ?? 0
        }
    }

    func cycleRepeat() {
        switch repeatMode {
        case .off: repeatMode = .all
        case .all: repeatMode = .one
        case .one: repeatMode = .off
        }
    }

    func stopAll() {
        loadTicket += 1
        stopEngines()
        queue = []
        original = []
        index = 0
        isPlaying = false
        position = 0
        duration = 0
        artwork = nil
        seed = nil
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        LiveActivityController.shared.end()
    }

    // MARK: Управление воспроизведением

    func togglePlay() {
        if isPlaying { pause() } else { resume() }
    }

    func resume() {
        guard current != nil else { return }
        if appleMode {
            if !appleLoaded { load(autoplay: true); return }
            let p = applePlayer
            appleCommandAt = Date()
            p.play()
            p.currentPlaybackRate = speed
        } else {
            if av.currentItem == nil { load(autoplay: true); return }
            activateSession()
            av.playImmediately(atRate: speed)
        }
        isPlaying = true
        publishNowPlaying()
        syncLive()
    }

    func pause() {
        if appleMode {
            appleCommandAt = Date()
            applePlayer.pause()
        } else {
            av.pause()
        }
        isPlaying = false
        publishNowPlaying()
        syncLive()
    }

    func next() {
        advance(auto: false)
    }

    func previous() {
        guard !queue.isEmpty else { return }
        if position > 3 {
            seek(to: 0)
        } else if index > 0 {
            index -= 1
            load(autoplay: true)
        } else if repeatMode == .all {
            index = queue.count - 1
            load(autoplay: true)
        } else {
            seek(to: 0)
        }
    }

    func seek(to t: Double) {
        let target = max(0, min(t, duration > 0 ? duration : t))
        position = target
        if appleMode {
            if appleLoaded {
                appleCommandAt = Date()
                applePlayer.currentPlaybackTime = target
            }
        } else {
            av.seek(to: CMTime(seconds: target, preferredTimescale: 600),
                    toleranceBefore: .zero, toleranceAfter: .zero)
        }
        publishNowPlaying()
        syncLive()
    }

    func setSpeed(_ s: Float) {
        speed = s
        if isPlaying {
            if appleMode {
                applePlayer.currentPlaybackRate = s
            } else {
                av.rate = s
            }
        }
        publishNowPlaying()
    }

    func setSleep(minutes: Int?) {
        sleepTimer?.invalidate()
        sleepTimer = nil
        guard let m = minutes else { sleepRemaining = nil; return }
        sleepRemaining = m * 60
        sleepTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] t in
            guard let self = self, let r = self.sleepRemaining else { t.invalidate(); return }
            if r <= 1 {
                self.sleepRemaining = nil
                t.invalidate()
                self.pause()
            } else {
                self.sleepRemaining = r - 1
            }
        }
    }

    func refreshLive() {
        if settings?.liveActivity == false {
            LiveActivityController.shared.end()
        } else {
            syncLive()
        }
    }

    // MARK: Загрузка трека

    private func activateSession() {
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .default, options: [])
        try? s.setActive(true)
    }

    private func stopEngines() {
        av.pause()
        av.replaceCurrentItem(with: nil)
        statusObs = nil
        if let o = endObserver {
            NotificationCenter.default.removeObserver(o)
            endObserver = nil
        }
        if appleLoaded {
            applePlayer.stop()
        }
        appleLoaded = false
        appleReady = false
    }

    private func load(autoplay: Bool) {
        guard let t = current else { return }
        stopEngines()
        loadTicket += 1
        let ticket = loadTicket
        duration = t.duration
        position = 0
        applePeak = 0
        updateArtwork(for: t)

        switch t.source {
        case .file(let name):
            appleMode = false
            startLocal(url: Paths.music.appendingPathComponent(name), autoplay: autoplay)
            finishLoad(autoplay: autoplay)
        case .remote(let link):
            appleMode = false
            if let url = URL(string: link) {
                startLocal(url: url, autoplay: autoplay)
                finishLoad(autoplay: autoplay)
            } else {
                banner = "Некорректная ссылка на поток"
                isPlaying = false
            }
        case .apple(let pid):
            appleMode = true   // пока ищем трек в медиатеке
            isPlaying = autoplay
            publishNowPlaying()
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let mi = AppleMusicLibrary.item(pid)
                DispatchQueue.main.async {
                    guard let self = self, self.loadTicket == ticket else { return }
                    self.startApple(mi, autoplay: autoplay)
                }
            }
        }
    }

    private func finishLoad(autoplay: Bool) {
        isPlaying = autoplay
        publishNowPlaying()
        syncLive()
    }

    private func startLocal(url: URL, autoplay: Bool) {
        let item = AVPlayerItem(url: url)
        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime,
                                                             object: item, queue: .main) { [weak self] _ in
            self?.handleEnded()
        }
        statusObs = item.observe(\.status, options: [.new]) { [weak self] it, _ in
            guard it.status == .failed else { return }
            let msg = it.error?.localizedDescription ?? "неизвестная ошибка"
            DispatchQueue.main.async {
                self?.banner = "Не удалось воспроизвести: \(msg)"
                self?.isPlaying = false
                self?.publishNowPlaying()
                self?.syncLive()
            }
        }
        av.replaceCurrentItem(with: item)
        if autoplay {
            activateSession()
            av.playImmediately(atRate: speed)
        }
    }

    private func startApple(_ mi: MPMediaItem?, autoplay: Bool) {
        guard AppleMusicLibrary.authorized, let mi = mi else {
            banner = AppleMusicLibrary.authorized ? "Трек не найден в медиатеке" : "Нет доступа к медиатеке Apple Music"
            isPlaying = false
            publishNowPlaying()
            syncLive()
            return
        }

        // Обычный файл (куплен или загружен без защиты): играем как локальный
        if let url = mi.assetURL, !mi.hasProtectedAsset {
            appleMode = false
            startLocal(url: url, autoplay: autoplay)
            finishLoad(autoplay: autoplay)
            return
        }

        // Трек из подписки Apple Music: пробуем несколько способов запуска по очереди
        appleMode = true
        appleLoaded = true
        appleReady = false

        let storeID = mi.playbackStoreID
        let hasStore = !storeID.isEmpty && storeID != "0"
        var attempts: [(Bool, Bool)] = []          // (системный плеер, по store ID)
        if !mi.isCloudItem { attempts.append((false, false)) }
        if hasStore { attempts.append((false, true)) }
        if !mi.isCloudItem { attempts.append((true, false)) }
        if hasStore { attempts.append((true, true)) }
        if attempts.isEmpty { attempts = [(false, false), (true, false)] }

        tryApple(mi, attempts: attempts, i: 0, autoplay: autoplay, ticket: loadTicket, lastError: nil)
        finishLoad(autoplay: autoplay)
    }

    private final class Once {
        var done = false
    }

    private func tryApple(_ mi: MPMediaItem, attempts: [(Bool, Bool)], i: Int,
                          autoplay: Bool, ticket: Int, lastError: String?) {
        guard loadTicket == ticket else { return }
        guard i < attempts.count else {
            banner = "Apple Music: " + (lastError ?? "не удалось начать воспроизведение")
            isPlaying = false
            publishNowPlaying()
            syncLive()
            return
        }

        appleCtx = (mi, attempts, i, autoplay)
        let useSystem = attempts[i].0
        let useStore = attempts[i].1
        let p: MPMusicPlayerController = useSystem ? MPMusicPlayerController.systemMusicPlayer
                                                   : MPMusicPlayerController.applicationMusicPlayer
        applePlayer = p
        p.shuffleMode = .off
        p.repeatMode = .none
        if useStore {
            p.setQueue(with: MPMusicPlayerStoreQueueDescriptor(storeIDs: [mi.playbackStoreID]))
        } else {
            p.setQueue(with: MPMediaItemCollection(items: [mi]))
        }

        let once = Once()
        let proceed: (String?) -> Void = { [weak self] err in
            guard let self = self, !once.done, self.loadTicket == ticket else { return }
            once.done = true
            if let err = err {
                self.tryApple(mi, attempts: attempts, i: i + 1, autoplay: autoplay,
                              ticket: ticket, lastError: err)
                return
            }
            self.appleReady = true
            self.appleStart = Date()
            self.appleCommandAt = Date()
            if autoplay {
                p.play()
                p.currentPlaybackRate = self.speed
            }
        }
        p.prepareToPlay { error in
            DispatchQueue.main.async { proceed(error?.localizedDescription) }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 7) { proceed("превышено время ожидания") }
    }

    private func advance(auto: Bool) {
        guard !queue.isEmpty else { return }
        if index + 1 < queue.count {
            index += 1
            load(autoplay: true)
        } else if repeatMode == .all || !auto {
            index = 0
            load(autoplay: true)
        } else {
            index = 0
            load(autoplay: false)
        }
    }

    private func handleEnded() {
        if repeatMode == .one {
            load(autoplay: true)
        } else {
            advance(auto: true)
        }
    }

    // MARK: Таймер состояния

    private func tick() {
        guard isPlaying, !scrubbing else { return }
        if appleMode {
            guard appleReady else { return }
            let p = applePlayer
            let t = p.currentPlaybackTime
            if t.isFinite, abs(t - position) > 0.05 { position = t }
            applePeak = max(applePeak, position)

            let sinceStart = Date().timeIntervalSince(appleStart)
            let sinceCmd = Date().timeIntervalSince(appleCommandAt)
            let state = p.playbackState
            if sinceStart > 4, sinceCmd > 3 {
                if state == .stopped || state == .interrupted {
                    if applePeak > max(1, duration - 3) {
                        handleEnded()
                    } else if applePeak < 1 {
                        if let ctx = appleCtx, ctx.index + 1 < ctx.attempts.count {
                            appleReady = false
                            tryApple(ctx.item, attempts: ctx.attempts, i: ctx.index + 1,
                                     autoplay: ctx.autoplay, ticket: loadTicket,
                                     lastError: "плеер не запустился")
                        } else {
                            banner = "Не удалось воспроизвести трек из Apple Music"
                            isPlaying = false
                            publishNowPlaying()
                            syncLive()
                        }
                    }
                } else if state == .paused {
                    isPlaying = false
                    publishNowPlaying()
                    syncLive()
                }
            }
        } else {
            let t = av.currentTime().seconds
            if t.isFinite, abs(t - position) > 0.05 { position = t }
            if let d = av.currentItem?.duration.seconds, d.isFinite, d > 0, abs(d - duration) > 1 {
                duration = d
            }
        }
    }

    // MARK: Обложка и цвет темы

    private func updateArtwork(for t: Track) {
        artTicket += 1
        let ticket = artTicket
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let img = ArtworkLoader.image(for: t, maxSide: 800)
            let seed: Seed? = img.flatMap { dominantSeed($0) }
            DispatchQueue.main.async {
                guard let self = self, self.artTicket == ticket else { return }
                withAnimation(.easeInOut(duration: 0.6)) {
                    self.artwork = img
                    self.seed = seed
                }
                self.publishNowPlaying()
                self.syncLive()
            }
        }
    }

    // MARK: Экран блокировки, Dynamic Island

    private func publishNowPlaying() {
        guard let t = current else { return }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: t.title,
            MPMediaItemPropertyArtist: t.artist,
            MPMediaItemPropertyAlbumTitle: t.album,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: position,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? Double(speed) : 0.0,
            MPNowPlayingInfoPropertyDefaultPlaybackRate: 1.0
        ]
        if let img = artwork {
            info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: img.size) { _ in img }
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func syncLive() {
        guard settings?.liveActivity ?? true, let t = current else { return }
        LiveActivityController.shared.sync(title: t.title, artist: t.artist, isPlaying: isPlaying,
                                           position: position, duration: duration,
                                           hue: seed?.h ?? 0.74)
    }

    private func onMain(_ f: @escaping () -> Void) {
        if Thread.isMainThread { f() } else { DispatchQueue.main.async(execute: f) }
    }

    private func configureRemote() {
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.addTarget { [weak self] _ in
            self?.onMain { self?.resume() }
            return .success
        }
        c.pauseCommand.addTarget { [weak self] _ in
            self?.onMain { self?.pause() }
            return .success
        }
        c.togglePlayPauseCommand.addTarget { [weak self] _ in
            self?.onMain { self?.togglePlay() }
            return .success
        }
        c.nextTrackCommand.addTarget { [weak self] _ in
            self?.onMain { self?.next() }
            return .success
        }
        c.previousTrackCommand.addTarget { [weak self] _ in
            self?.onMain { self?.previous() }
            return .success
        }
        c.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let e = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            self?.onMain { self?.seek(to: e.positionTime) }
            return .success
        }
    }

    private func handleInterruption(_ n: Notification) {
        guard let raw = n.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
        if type == .began {
            if isPlaying {
                isPlaying = false
                publishNowPlaying()
                syncLive()
            }
        } else if let opt = n.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt,
                  AVAudioSession.InterruptionOptions(rawValue: opt).contains(.shouldResume) {
            resume()
        }
    }

    private func handleRoute(_ n: Notification) {
        guard let raw = n.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
              let reason = AVAudioSession.RouteChangeReason(rawValue: raw) else { return }
        if reason == .oldDeviceUnavailable, isPlaying {
            pause()
        }
    }
}
