import SwiftUI
import AVKit

// MARK: Кнопки

struct PressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct IconButton: View {
    let system: String
    var size: CGFloat = 44
    var filled = false
    var active = false
    let action: () -> Void
    @Environment(\.md3) private var c

    var body: some View {
        Button(action: action) {
            ZStack {
                if filled || active {
                    Circle().fill(active ? c.primaryContainer : c.secondaryContainer)
                }
                Image(systemName: system)
                    .font(.system(size: size * 0.42, weight: .semibold))
                    .foregroundColor(active ? c.onPrimaryContainer : (filled ? c.onSecondaryContainer : c.onSurfaceVariant))
            }
            .frame(width: size, height: size)
            .contentShape(Rectangle())
        }
        .buttonStyle(PressStyle())
    }
}

struct PillButton: View {
    let title: String
    var icon: String? = nil
    var tonal = false
    let action: () -> Void
    @Environment(\.md3) private var c

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if let icon = icon {
                    Image(systemName: icon).font(.system(size: 16, weight: .semibold))
                }
                Text(title).font(.system(size: 15, weight: .semibold))
            }
            .padding(.horizontal, 20)
            .frame(height: 48)
            .background(Capsule().fill(tonal ? c.secondaryContainer : c.primary))
            .foregroundColor(tonal ? c.onSecondaryContainer : c.onPrimary)
        }
        .buttonStyle(PressStyle())
    }
}

struct FABLabel: View {
    let title: String
    let icon: String
    @Environment(\.md3) private var c

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon).font(.system(size: 20, weight: .semibold))
            Text(title).font(.system(size: 16, weight: .semibold))
        }
        .padding(.horizontal, 22)
        .frame(height: 56)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(c.primaryContainer))
        .foregroundColor(c.onPrimaryContainer)
        .shadow(color: Color.black.opacity(0.18), radius: 8, x: 0, y: 4)
    }
}

struct MiniProgress: View {
    @ObservedObject var clock: PlaybackClock
    let duration: Double
    @Environment(\.md3) private var c

    var body: some View {
        let p: CGFloat = duration > 0 ? CGFloat(min(1, max(0, clock.position / duration))) : 0
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(c.onPrimaryContainer.opacity(0.15))
                Capsule().fill(c.primary).frame(width: g.size.width * p)
            }
        }
        .frame(height: 3)
        .padding(.horizontal, 18)
        .padding(.vertical, 9)
    }
}

/// Кнопка play/pause: при воспроизведении "круг" превращается в скруглённый квадрат.
struct PlayPauseButton: View {
    let isPlaying: Bool
    var width: CGFloat = 92
    var height: CGFloat = 68
    let action: () -> Void
    @Environment(\.md3) private var c

    var body: some View {
        Button(action: action) {
            ZStack {
                RoundedRectangle(cornerRadius: isPlaying ? height * 0.30 : height / 2, style: .continuous)
                    .fill(c.primary)
                Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: height * 0.40, weight: .bold))
                    .foregroundColor(c.onPrimary)
            }
            .frame(width: width, height: height)
            .animation(.spring(response: 0.38, dampingFraction: 0.68), value: isPlaying)
        }
        .buttonStyle(PressStyle())
    }
}

// MARK: Слайдер

struct MD3Slider: View {
    @Binding var value: Double
    var range: ClosedRange<Double>
    var onEditing: (Bool) -> Void
    @Environment(\.md3) private var c

    var body: some View {
        GeometryReader { geo in
            let w = max(1, geo.size.width)
            let span = max(0.001, range.upperBound - range.lowerBound)
            let frac = CGFloat(min(max((value - range.lowerBound) / span, 0), 1))
            let x = w * frac
            ZStack(alignment: .leading) {
                Capsule().fill(c.secondaryContainer).frame(height: 14)
                Capsule().fill(c.primary).frame(width: max(0, x - 6), height: 14)
                Capsule().fill(c.primary).frame(width: 5, height: 40).offset(x: min(max(x - 2.5, 0), w - 5))
            }
            .frame(height: 44)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { g in
                        onEditing(true)
                        let f = min(max(g.location.x / w, 0), 1)
                        value = range.lowerBound + Double(f) * span
                    }
                    .onEnded { _ in onEditing(false) }
            )
        }
        .frame(height: 44)
    }
}

// MARK: Навигация

struct NavItem {
    let title: String
    let icon: String
    let iconFilled: String
}

struct NavBar: View {
    @Binding var selection: Int
    let items: [NavItem]
    @Environment(\.md3) private var c

    var body: some View {
        HStack(spacing: 0) {
            ForEach(items.indices, id: \.self) { i in
                let on = selection == i
                Button {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) { selection = i }
                } label: {
                    VStack(spacing: 4) {
                        ZStack {
                            Capsule()
                                .fill(on ? c.secondaryContainer : Color.clear)
                                .frame(width: on ? 64 : 32, height: 32)
                            Image(systemName: on ? items[i].iconFilled : items[i].icon)
                                .font(.system(size: 19, weight: .medium))
                                .foregroundColor(on ? c.onSecondaryContainer : c.onSurfaceVariant)
                        }
                        Text(items[i].title)
                            .font(.system(size: 12, weight: on ? .bold : .medium))
                            .foregroundColor(on ? c.onSurface : c.onSurfaceVariant)
                    }
                    .frame(maxWidth: .infinity)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 12)
        .padding(.bottom, 8)
        .background(c.surfaceContainer.ignoresSafeArea(edges: .bottom))
    }
}

// MARK: Мини-плеер

struct MiniPlayer: View {
    @EnvironmentObject var player: PlayerModel
    @Environment(\.md3) private var c

    var body: some View {
        if let t = player.current {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    ArtworkView(track: t, size: 48, radius: 14)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(t.title)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(c.onPrimaryContainer)
                            .lineLimit(1)
                        Text(t.artist)
                            .font(.system(size: 13))
                            .foregroundColor(c.onPrimaryContainer.opacity(0.75))
                            .lineLimit(1)
                    }
                    Spacer(minLength: 8)
                    PlayPauseButton(isPlaying: player.isPlaying, width: 56, height: 44) { player.togglePlay() }
                    IconButton(system: "forward.fill", size: 40) { player.next() }
                }
                .padding(.horizontal, 12)
                .padding(.top, 10)

                MiniProgress(clock: player.clock, duration: player.duration)
            }
            .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(c.primaryContainer))
        }
    }
}

// MARK: Обложка

struct ArtworkView: View {
    let track: Track?
    var size: CGFloat
    var radius: CGFloat
    @Environment(\.md3) private var c
    @State private var image: UIImage? = nil

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: radius, style: .continuous).fill(c.primaryContainer)
            if let image = image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Image(systemName: "music.note")
                    .font(.system(size: size * 0.38, weight: .semibold))
                    .foregroundColor(c.onPrimaryContainer)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
        .task(id: track?.id) {
            guard let t = track else { image = nil; return }
            let side = max(160, size * 2)
            image = await Task.detached(priority: .utility) {
                ArtworkLoader.image(for: t, maxSide: side)
            }.value
        }
    }
}

// MARK: Строка песни

struct SongRow: View {
    @EnvironmentObject var player: PlayerModel
    @EnvironmentObject var library: LibraryStore
    @Environment(\.md3) private var c
    let track: Track
    var onPlay: () -> Void
    var onRemove: (() -> Void)? = nil

    var body: some View {
        let isCurrent = player.current?.id == track.id
        let fav = library.favorites.contains(track.id)
        HStack(spacing: 12) {
            Button(action: onPlay) {
                HStack(spacing: 14) {
                    ZStack {
                        ArtworkView(track: track, size: 50, radius: 14)
                        if isCurrent {
                            RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.black.opacity(0.38))
                            Image(systemName: player.isPlaying ? "waveform" : "pause.fill")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.white)
                        }
                    }
                    VStack(alignment: .leading, spacing: 3) {
                        Text(track.title)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(isCurrent ? c.primary : c.onSurface)
                            .lineLimit(1)
                        Text(track.artist + (track.duration > 0 ? " · " + formatTime(track.duration) : ""))
                            .font(.system(size: 13))
                            .foregroundColor(c.onSurfaceVariant)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if fav {
                Image(systemName: "heart.fill").font(.system(size: 14)).foregroundColor(c.primary)
            }

            Menu {
                Button { player.playNext(track) } label: { Label("Играть следующим", systemImage: "forward.end") }
                Button { player.addToQueue(track) } label: { Label("Добавить в очередь", systemImage: "list.bullet") }
                Button { library.toggleFavorite(track.id) } label: {
                    Label(fav ? "Убрать из любимого" : "В любимое", systemImage: fav ? "heart.slash" : "heart")
                }
                Menu {
                    ForEach(library.playlists) { p in
                        Button(p.name) { library.add(track.id, to: p.id) }
                    }
                    Button {
                        library.newPlaylistSeedTrack = track.id
                        library.showNewPlaylist = true
                    } label: { Label("Новый плейлист…", systemImage: "plus") }
                } label: { Label("Добавить в плейлист", systemImage: "music.note.list") }
                if let onRemove = onRemove {
                    Button(role: .destructive, action: onRemove) {
                        Label("Убрать из плейлиста", systemImage: "minus.circle")
                    }
                }
                Button(role: .destructive) {
                    player.remove(trackIDs: [track.id])
                    library.delete(track)
                } label: { Label("Удалить из библиотеки", systemImage: "trash") }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(c.onSurfaceVariant)
                    .frame(width: 40, height: 40)
                    .contentShape(Rectangle())
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 6)
        .background(isCurrent ? c.secondaryContainer.opacity(0.55) : Color.clear)
    }
}

// MARK: Прочее

struct ScreenHeader: View {
    let title: String
    var subtitle: String? = nil
    @Environment(\.md3) private var c

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 34, weight: .bold))
                .foregroundColor(c.onSurface)
            if let subtitle = subtitle {
                Text(subtitle)
                    .font(.system(size: 15))
                    .foregroundColor(c.onSurfaceVariant)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 20)
    }
}

struct SearchField: View {
    @Binding var text: String
    var placeholder: String
    @Environment(\.md3) private var c

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundColor(c.onSurfaceVariant)
            TextField(placeholder, text: $text)
                .foregroundColor(c.onSurface)
                .disableAutocorrection(true)
            if !text.isEmpty {
                Button { text = "" } label: {
                    Image(systemName: "xmark.circle.fill").foregroundColor(c.onSurfaceVariant)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 52)
        .background(Capsule().fill(c.surfaceContainerHigh))
        .padding(.horizontal, 16)
    }
}

struct ChipButton: View {
    let title: String
    let selected: Bool
    let action: () -> Void
    @Environment(\.md3) private var c

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if selected { Image(systemName: "checkmark").font(.system(size: 12, weight: .bold)) }
                Text(title).font(.system(size: 14, weight: .medium))
            }
            .padding(.horizontal, 14)
            .frame(height: 34)
            .background(RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(selected ? c.secondaryContainer : Color.clear))
            .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous)
                .stroke(selected ? Color.clear : c.outlineVariant, lineWidth: 1))
            .foregroundColor(selected ? c.onSecondaryContainer : c.onSurfaceVariant)
        }
        .buttonStyle(PressStyle())
    }
}

struct EmptyStateView: View {
    let icon: String
    let title: String
    let text: String
    @Environment(\.md3) private var c

    var body: some View {
        VStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 44, style: .continuous).fill(c.primaryContainer)
                    .frame(width: 120, height: 120)
                Image(systemName: icon)
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundColor(c.onPrimaryContainer)
            }
            Text(title).font(.system(size: 22, weight: .bold)).foregroundColor(c.onSurface)
            Text(text)
                .font(.system(size: 15))
                .foregroundColor(c.onSurfaceVariant)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
        }
        .padding(.vertical, 24)
        .frame(maxWidth: .infinity)
    }
}

struct ToastView: View {
    let text: String
    @Environment(\.md3) private var c

    var body: some View {
        Text(text)
            .font(.system(size: 14, weight: .medium))
            .foregroundColor(c.onSurface)
            .padding(.horizontal, 18)
            .padding(.vertical, 12)
            .background(Capsule().fill(c.surfaceContainerHighest))
            .shadow(color: Color.black.opacity(0.2), radius: 8, x: 0, y: 3)
    }
}

struct AirPlayButton: UIViewRepresentable {
    var tint: UIColor

    func makeUIView(context: Context) -> AVRoutePickerView {
        let v = AVRoutePickerView()
        v.tintColor = tint
        v.activeTintColor = tint
        return v
    }

    func updateUIView(_ v: AVRoutePickerView, context: Context) {
        v.tintColor = tint
        v.activeTintColor = tint
    }
}
