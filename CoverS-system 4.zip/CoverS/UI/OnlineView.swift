import SwiftUI
import AVKit

struct OnlineView: View {
    @EnvironmentObject var online: OnlineStore
    @EnvironmentObject var player: PlayerModel
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var settings: AppSettings
    @Environment(\.md3) private var c
    @State private var query = ""

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                ScreenHeader(title: "Онлайн", subtitle: "Подборки и радио из бесплатных источников")
                    .padding(.top, 20)
                picks
            }
            .padding(.bottom, 110)
        }
    }

    private var picks: some View {
        VStack(alignment: .leading, spacing: 14) {
            SearchField(text: $query, placeholder: "Свой запрос: вокалоиды, lo-fi, 80-е…")
            HStack {
                PillButton(title: "Найти подборку", icon: "magnifyingglass") { search() }
            }
            .padding(.horizontal, 16)

            Text("Готовые шаблоны")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(c.onSurface)
                .padding(.horizontal, 20)
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 3), spacing: 10) {
                ForEach(Genre.all) { g in
                    Button { openGenre(g) } label: {
                        VStack(spacing: 8) {
                            Image(systemName: g.icon)
                                .font(.system(size: 22, weight: .semibold))
                                .foregroundColor(c.onPrimaryContainer)
                            Text(g.title)
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(c.onSurface)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 80)
                        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(c.primaryContainer.opacity(0.7)))
                    }
                    .buttonStyle(PressStyle())
                }
            }
            .padding(.horizontal, 16)

            Text("Источники")
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(c.primary)
                .padding(.horizontal, 20)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ChipButton(title: "Audius", selected: online.useAudius) { online.useAudius.toggle() }
                    ChipButton(title: "Радио", selected: online.useRadio) { online.useRadio.toggle() }
                    ChipButton(title: settings.jamendoKey.isEmpty ? "Jamendo (нужен ключ)" : "Jamendo",
                               selected: online.useJamendo && !settings.jamendoKey.isEmpty) {
                        online.useJamendo.toggle()
                    }
                }
                .padding(.horizontal, 16)
            }

            results
        }
    }

    @ViewBuilder private var results: some View {
        if online.loading {
            HStack(spacing: 12) {
                ProgressView()
                Text("Собираю подборку…")
                    .font(.system(size: 15))
                    .foregroundColor(c.onSurfaceVariant)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
        } else if let e = online.error {
            Text(e)
                .font(.system(size: 14))
                .foregroundColor(c.onSurfaceVariant)
                .padding(.horizontal, 20)
        } else if !online.results.isEmpty {
            let tracks = online.results.map { $0.asTrack() }
            VStack(alignment: .leading, spacing: 8) {
                Text("Подборка: \(online.title)")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(c.onSurface)
                    .padding(.horizontal, 20)
                HStack(spacing: 10) {
                    PillButton(title: "Играть", icon: "play.fill") { player.play(tracks, at: 0) }
                    PillButton(title: "Вперемешку", icon: "shuffle", tonal: true) { player.playShuffled(tracks) }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 6)
                ForEach(Array(online.results.enumerated()), id: \.element.id) { i, item in
                    OnlineRow(item: item) { player.play(tracks, at: i) }
                }
            }
        }
    }

    private func openGenre(_ g: Genre) {
        online.load(title: g.title, genre: g, query: nil, jamendoKey: settings.jamendoKey)
    }

    private func search() {
        let raw = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }
        online.load(title: raw, genre: nil, query: OnlineStore.normalize(raw), jamendoKey: settings.jamendoKey)
    }
}

struct OnlineRow: View {
    let item: OnlineTrack
    var onPlay: () -> Void
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var player: PlayerModel
    @EnvironmentObject var downloads: DownloadManager
    @Environment(\.md3) private var c

    var body: some View {
        let t = item.asTrack()
        let isCurrent = player.current?.id == item.id
        HStack(spacing: 12) {
            Button(action: onPlay) {
                HStack(spacing: 14) {
                    ArtworkView(track: t, size: 50, radius: 14)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(item.title)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(isCurrent ? c.primary : c.onSurface)
                            .lineLimit(1)
                        Text(item.artist + " · " + item.service)
                            .font(.system(size: 13))
                            .foregroundColor(c.onSurfaceVariant)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                    if item.duration <= 0 {
                        Text("LIVE")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(c.onPrimaryContainer)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 3)
                            .background(Capsule().fill(c.primaryContainer))
                    }
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Menu {
                Button { player.playNext(t) } label: { Label("Играть следующим", systemImage: "forward.end") }
                Button { player.addToQueue(t) } label: { Label("Добавить в очередь", systemImage: "list.bullet") }
                Button { library.addRemote(t) } label: { Label("В библиотеку (онлайн)", systemImage: "plus") }
                if let dl = item.downloadURL {
                    Button {
                        downloads.start(dl, name: item.artist + " - " + item.title)
                    } label: { Label("Скачать в библиотеку", systemImage: "arrow.down.circle") }
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(c.onSurfaceVariant)
                    .frame(width: 40, height: 40)
                    .contentShape(Rectangle())
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 6)
        .background(isCurrent ? c.secondaryContainer.opacity(0.55) : Color.clear)
    }
}
