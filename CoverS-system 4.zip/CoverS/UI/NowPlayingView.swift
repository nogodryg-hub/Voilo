import SwiftUI

struct NowPlayingView: View {
    @EnvironmentObject var player: PlayerModel
    @EnvironmentObject var library: LibraryStore
    @Environment(\.md3) private var c
    @Environment(\.dismiss) private var dismiss
    @State private var showQueue = false
    @State private var dragY: CGFloat = 0

    var body: some View {
        GeometryReader { geo in
            let art = min(geo.size.width - 56, geo.size.height * 0.40)
            ZStack {
                c.surface.ignoresSafeArea()
                LinearGradient(colors: [c.primaryContainer.opacity(0.7), c.surface],
                               startPoint: .top, endPoint: .center)
                    .ignoresSafeArea()

                VStack(spacing: 0) {
                    VStack(spacing: 0) {
                        topBar
                        Spacer(minLength: 8)
                        ArtworkView(track: player.current, size: art, radius: 40)
                            .shadow(color: Color.black.opacity(0.25), radius: 18, x: 0, y: 10)
                    }
                    .offset(y: dragY)
                    .gesture(
                        DragGesture()
                            .onChanged { v in
                                if v.translation.height > 0 { dragY = v.translation.height }
                            }
                            .onEnded { v in
                                if v.translation.height > 140 {
                                    dismiss()
                                } else {
                                    withAnimation(.spring()) { dragY = 0 }
                                }
                            }
                    )

                    Spacer(minLength: 14)
                    titleBlock
                    slider.padding(.top, 8)
                    controls.padding(.top, 8)
                    secondary.padding(.top, 14)
                    Spacer(minLength: 8)
                }
                .padding(.horizontal, 24)
            }
        }
        .sheet(isPresented: $showQueue) {
            QueueSheet()
                .environment(\.md3, c)
        }
    }

    private var topBar: some View {
        HStack {
            IconButton(system: "chevron.down", size: 44, filled: true) { dismiss() }
            Spacer()
            Text("Сейчас играет")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(c.onSurfaceVariant)
            Spacer()
            IconButton(system: "list.bullet", size: 44, filled: true) { showQueue = true }
        }
        .padding(.top, 8)
    }

    private var titleBlock: some View {
        HStack(alignment: .center, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(player.current?.title ?? "")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(c.onSurface)
                    .lineLimit(1)
                Text(player.current?.artist ?? "")
                    .font(.system(size: 16))
                    .foregroundColor(c.onSurfaceVariant)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            if let t = player.current {
                let fav = library.favorites.contains(t.id)
                IconButton(system: fav ? "heart.fill" : "heart", size: 48, filled: true, active: fav) {
                    library.toggleFavorite(t.id)
                }
            }
        }
    }

    private var slider: some View {
        Group {
            if player.current?.isLive == true {
                Text("ПРЯМОЙ ЭФИР")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(c.primary)
                    .frame(maxWidth: .infinity)
                    .frame(height: 44)
            } else {
                SeekBar(clock: player.clock)
            }
        }
    }

    private var controls: some View {
        HStack(spacing: 8) {
            IconButton(system: "shuffle", size: 44, active: player.shuffle) { player.setShuffle(!player.shuffle) }
            IconButton(system: "backward.fill", size: 52, filled: true) { player.previous() }
            PlayPauseButton(isPlaying: player.isPlaying, width: 92, height: 68) { player.togglePlay() }
            IconButton(system: "forward.fill", size: 52, filled: true) { player.next() }
            IconButton(system: player.repeatMode == .one ? "repeat.1" : "repeat",
                       size: 44, active: player.repeatMode != .off) { player.cycleRepeat() }
        }
        .frame(maxWidth: .infinity)
    }

    private var secondary: some View {
        HStack {
            Menu {
                ForEach([15, 30, 45, 60], id: \.self) { m in
                    Button("\(m) минут") { player.setSleep(minutes: m) }
                }
                if player.sleepRemaining != nil {
                    Button(role: .destructive) { player.setSleep(minutes: nil) } label: {
                        Label("Выключить таймер", systemImage: "xmark")
                    }
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "moon.zzz")
                    if let r = player.sleepRemaining {
                        Text(formatTime(Double(r))).font(.system(size: 13, weight: .semibold)).monospacedDigit()
                    }
                }
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(player.sleepRemaining != nil ? c.onPrimaryContainer : c.onSurfaceVariant)
                .padding(.horizontal, 14)
                .frame(height: 44)
                .background(Capsule().fill(player.sleepRemaining != nil ? c.primaryContainer : Color.clear))
            }

            Spacer()

            Menu {
                ForEach([Float(0.75), 1.0, 1.25, 1.5, 2.0], id: \.self) { v in
                    Button {
                        player.setSpeed(v)
                    } label: {
                        if player.speed == v {
                            Label(speedText(v), systemImage: "checkmark")
                        } else {
                            Text(speedText(v))
                        }
                    }
                }
            } label: {
                Text(speedText(player.speed))
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(player.speed != 1.0 ? c.onPrimaryContainer : c.onSurfaceVariant)
                    .padding(.horizontal, 14)
                    .frame(height: 44)
                    .background(Capsule().fill(player.speed != 1.0 ? c.primaryContainer : Color.clear))
            }

            Spacer()

            AirPlayButton(tint: UIColor(c.onSurfaceVariant))
                .frame(width: 44, height: 44)
        }
    }

    private func speedText(_ v: Float) -> String {
        v == Float(Int(v)) ? "\(Int(v))×" : String(format: "%g×", v)
    }
}

struct QueueSheet: View {
    @EnvironmentObject var player: PlayerModel
    @Environment(\.md3) private var c
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            c.surface.ignoresSafeArea()
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Text("Очередь")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(c.onSurface)
                    Spacer()
                    IconButton(system: "xmark", size: 40, filled: true) { dismiss() }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)

                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 0) {
                        ForEach(Array(player.queue.enumerated()), id: \.offset) { i, t in
                            let isCur = i == player.index
                            HStack(spacing: 12) {
                                Button { player.jump(to: i) } label: {
                                    HStack(spacing: 12) {
                                        ArtworkView(track: t, size: 44, radius: 12)
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text(t.title)
                                                .font(.system(size: 15, weight: .semibold))
                                                .foregroundColor(isCur ? c.primary : c.onSurface)
                                                .lineLimit(1)
                                            Text(t.artist)
                                                .font(.system(size: 13))
                                                .foregroundColor(c.onSurfaceVariant)
                                                .lineLimit(1)
                                        }
                                        Spacer(minLength: 0)
                                    }
                                    .contentShape(Rectangle())
                                }
                                .buttonStyle(.plain)
                                if isCur {
                                    Image(systemName: "waveform").foregroundColor(c.primary)
                                } else {
                                    IconButton(system: "xmark", size: 36) { player.removeFromQueue(at: i) }
                                }
                            }
                            .padding(.horizontal, 20)
                            .padding(.vertical, 6)
                            .background(isCur ? c.secondaryContainer.opacity(0.55) : Color.clear)
                        }
                    }
                    .padding(.bottom, 30)
                }
            }
        }
    }
}

struct SeekBar: View {
    @EnvironmentObject var player: PlayerModel
    @ObservedObject var clock: PlaybackClock
    @Environment(\.md3) private var c

    var body: some View {
        VStack(spacing: 2) {
            MD3Slider(value: $clock.position, range: 0...max(1, player.duration)) { editing in
                if editing {
                    player.scrubbing = true
                } else {
                    player.seek(to: clock.position)
                    player.scrubbing = false
                }
            }
            HStack {
                Text(formatTime(clock.position))
                Spacer()
                Text("-" + formatTime(max(0, player.duration - clock.position)))
            }
            .font(.system(size: 12, weight: .medium))
            .monospacedDigit()
            .foregroundColor(c.onSurfaceVariant)
        }
    }
}
