import Foundation

/// Единая загрузка: прямые ссылки скачиваются сразу (без плеера), файлы с устройства копируются.
/// Аудио попадает в библиотеку, видео (mp4) хранится в папке Videos и открывается офлайн.
final class DownloadManager: NSObject, ObservableObject, URLSessionDownloadDelegate {
    enum State: Equatable {
        case running
        case finished
        case failed(String)
    }

    struct Item: Identifiable {
        let id: UUID
        var url: URL?
        var name: String
        var format: String
        var total: Int64
        var received: Int64
        var state: State
        var isVideo: Bool
        var resumeData: Data? = nil
        var checked = false

        var progress: Double {
            total > 0 ? min(1, Double(received) / Double(total)) : 0
        }

        var sizeText: String {
            let n = total > 0 ? total : received
            return n > 0 ? ByteCountFormatter.string(fromByteCount: n, countStyle: .file) : "размер неизвестен"
        }
    }

    static let videoExts: Set<String> = ["mp4", "m4v", "mov"]

    @Published var items: [Item] = []
    @Published var videos: [URL] = []

    private var session: URLSession!
    private var tasks: [UUID: URLSessionDownloadTask] = [:]
    private var owners: [Int: UUID] = [:]
    private weak var library: LibraryStore?

    override init() {
        super.init()
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 30
        session = URLSession(configuration: cfg, delegate: self, delegateQueue: .main)
        reloadVideos()
    }

    func attach(library: LibraryStore) {
        self.library = library
    }

    // MARK: Видео в локальном хранилище

    func reloadVideos() {
        let items = (try? FileManager.default.contentsOfDirectory(at: Paths.videos,
                                                                  includingPropertiesForKeys: nil,
                                                                  options: [.skipsHiddenFiles])) ?? []
        videos = items.filter { DownloadManager.videoExts.contains($0.pathExtension.lowercased()) }
            .sorted { $0.lastPathComponent.localizedCaseInsensitiveCompare($1.lastPathComponent) == .orderedAscending }
    }

    func deleteVideo(_ url: URL) {
        try? FileManager.default.removeItem(at: url)
        reloadVideos()
    }

    // MARK: Вспомогательное

    private static func safeName(_ s: String) -> String {
        let bad = CharacterSet(charactersIn: "/\\:?*\"<>|")
        let cleaned = s.components(separatedBy: bad).joined(separator: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let cut = String(cleaned.prefix(80))
        return cut.isEmpty ? "file" : cut
    }

    private static func unique(_ dir: URL, _ base: String, _ ext: String) -> URL {
        var url = dir.appendingPathComponent(base + "." + ext)
        var n = 2
        while FileManager.default.fileExists(atPath: url.path) {
            url = dir.appendingPathComponent("\(base) (\(n)).\(ext)")
            n += 1
        }
        return url
    }

    private static func resolveExt(url: URL, mime: String) -> String {
        let e = url.pathExtension.lowercased()
        if !e.isEmpty && e.count <= 5 { return e }
        if mime.contains("video/quicktime") { return "mov" }
        if mime.hasPrefix("video/") { return "mp4" }
        if mime.contains("flac") { return "flac" }
        if mime.contains("wav") { return "wav" }
        if mime.contains("aac") || mime.contains("mp4") { return "m4a" }
        return "mp3"
    }

    private static func describe(_ e: NSError) -> String {
        switch e.code {
        case NSURLErrorNotConnectedToInternet: return "Нет подключения к интернету"
        case NSURLErrorTimedOut: return "Время ожидания истекло"
        case NSURLErrorNetworkConnectionLost: return "Соединение прервано"
        case NSURLErrorCancelled: return "Отменено"
        case NSURLErrorCannotFindHost, NSURLErrorCannotConnectToHost: return "Не удалось подключиться к серверу"
        default: return e.localizedDescription
        }
    }

    private func index(_ id: UUID) -> Int? {
        items.firstIndex { $0.id == id }
    }

    private func setState(_ id: UUID, _ s: State) {
        if let i = index(id) { items[i].state = s }
    }

    private func fail(_ id: UUID, _ message: String) {
        setState(id, .failed(message))
    }

    // MARK: Действия

    func start(_ link: String, name: String? = nil) {
        let trimmed = link.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed),
              let scheme = url.scheme?.lowercased(), scheme == "http" || scheme == "https" else {
            items.insert(Item(id: UUID(), url: nil, name: trimmed.isEmpty ? "Ссылка" : trimmed, format: "?",
                              total: -1, received: 0,
                              state: .failed("Нужна прямая ссылка http(s) на файл"), isVideo: false), at: 0)
            return
        }
        let ext = url.pathExtension.lowercased()
        let raw = name ?? (url.deletingPathExtension().lastPathComponent.removingPercentEncoding ?? "")
        let item = Item(id: UUID(), url: url, name: raw.isEmpty ? "Файл" : raw,
                        format: ext.isEmpty ? "?" : ext.uppercased(),
                        total: -1, received: 0, state: .running,
                        isVideo: DownloadManager.videoExts.contains(ext))
        items.insert(item, at: 0)
        launch(item.id, task: session.downloadTask(with: url))
    }

    private func launch(_ id: UUID, task: URLSessionDownloadTask) {
        tasks[id] = task
        owners[task.taskIdentifier] = id
        task.resume()
    }

    func cancel(_ id: UUID) {
        fail(id, "Отменено")
        tasks[id]?.cancel()
    }

    func retry(_ id: UUID) {
        guard let i = index(id), case .failed = items[i].state else { return }
        let item = items[i]
        let task: URLSessionDownloadTask
        if let data = item.resumeData {
            task = session.downloadTask(withResumeData: data)
        } else if let url = item.url {
            task = session.downloadTask(with: url)
            items[i].received = 0
        } else {
            return
        }
        items[i].state = .running
        items[i].resumeData = nil
        items[i].checked = false
        launch(id, task: task)
    }

    func dismiss(_ id: UUID) {
        items.removeAll { $0.id == id }
    }

    func clearFinished() {
        items.removeAll { $0.state != .running }
    }

    /// Файлы, выбранные пользователем на устройстве: копируем в хранилище приложения.
    func importPicked(_ urls: [URL]) {
        guard let library = library else { return }
        for u in urls {
            let ext = u.pathExtension.lowercased()
            let isVideo = DownloadManager.videoExts.contains(ext)
            let attrs = try? FileManager.default.attributesOfItem(atPath: u.path)
            let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            let id = UUID()
            let name = u.deletingPathExtension().lastPathComponent
            items.insert(Item(id: id, url: nil, name: name, format: ext.uppercased(),
                              total: size, received: size, state: .running, isVideo: isVideo), at: 0)
            if isVideo {
                let dest = DownloadManager.unique(Paths.videos, DownloadManager.safeName(name), ext)
                do {
                    try FileManager.default.copyItem(at: u, to: dest)
                    setState(id, .finished)
                    reloadVideos()
                } catch {
                    fail(id, error.localizedDescription)
                }
            } else {
                library.importFiles([u]) { [weak self] n in
                    self?.setState(id, n > 0 ? .finished : .failed("Файл не удалось распознать как аудио"))
                }
            }
        }
    }

    // MARK: URLSessionDownloadDelegate

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        guard let id = owners[downloadTask.taskIdentifier], let i = index(id) else { return }
        items[i].received = totalBytesWritten
        if totalBytesExpectedToWrite > 0 { items[i].total = totalBytesExpectedToWrite }

        if !items[i].checked, let http = downloadTask.response as? HTTPURLResponse {
            items[i].checked = true
            let mime = (http.value(forHTTPHeaderField: "Content-Type") ?? "").lowercased()
            if !(200..<300).contains(http.statusCode) {
                fail(id, "Сервер ответил кодом \(http.statusCode)")
                downloadTask.cancel()
                return
            }
            if mime.contains("text/html") {
                fail(id, "По ссылке открывается веб-страница, а не файл")
                downloadTask.cancel()
                return
            }
            if let url = items[i].url {
                let ext = DownloadManager.resolveExt(url: url, mime: mime)
                items[i].format = ext.uppercased()
                items[i].isVideo = DownloadManager.videoExts.contains(ext) || mime.hasPrefix("video/")
            }
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        guard let id = owners[downloadTask.taskIdentifier], let i = index(id) else { return }
        if case .failed = items[i].state { return }

        let http = downloadTask.response as? HTTPURLResponse
        let mime = (http?.value(forHTTPHeaderField: "Content-Type") ?? "").lowercased()
        if let h = http, !(200..<300).contains(h.statusCode) {
            fail(id, "Сервер ответил кодом \(h.statusCode)")
            return
        }
        if mime.contains("text/html") {
            fail(id, "По ссылке открывается веб-страница, а не файл")
            return
        }

        let source = items[i].url ?? downloadTask.originalRequest?.url
        let ext = source.map { DownloadManager.resolveExt(url: $0, mime: mime) } ?? "mp3"
        let isVideo = DownloadManager.videoExts.contains(ext) || mime.hasPrefix("video/")
        let base = DownloadManager.safeName(items[i].name)
        items[i].format = ext.uppercased()
        items[i].isVideo = isVideo

        do {
            if isVideo {
                let dest = DownloadManager.unique(Paths.videos, base, ext)
                try FileManager.default.moveItem(at: location, to: dest)
                items[i].state = .finished
                reloadVideos()
            } else {
                let dir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
                let dest = dir.appendingPathComponent(base + "." + ext)
                try FileManager.default.moveItem(at: location, to: dest)
                guard let library = library else {
                    fail(id, "Библиотека недоступна")
                    return
                }
                library.importFiles([dest]) { [weak self] n in
                    self?.setState(id, n > 0 ? .finished : .failed("Файл не удалось распознать как аудио"))
                }
            }
        } catch {
            fail(id, error.localizedDescription)
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let id = owners[task.taskIdentifier] else { return }
        owners[task.taskIdentifier] = nil
        tasks[id] = nil
        guard let error = error, let i = index(id) else { return }
        if case .failed = items[i].state { return }
        let ns = error as NSError
        items[i].resumeData = ns.userInfo[NSURLSessionDownloadTaskResumeData] as? Data
        items[i].state = .failed(DownloadManager.describe(ns))
    }
}
