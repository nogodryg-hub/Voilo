import SwiftUI

struct HomeView: View {
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var player: PlayerModel
    @Environment(\.md3) private var c
    var onAddFiles: () -> Void
    var onAddApple: () -> Void

    private var greeting: String {
        let h = Calendar.current.component(.hour, from: Date())
        switch h {
        case 5..<12: return "Доброе утро"
        case 12..<18: return "Добрый день"
        case 18..<23: return "Добрый вечер"
        default: return "Доброй ночи"
        }
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 26) {
                ScreenHeader(title: "Voilo", subtitle: greeting)
                if library.tracks.isEmpty {
                    emptyState
                } else {
                    heroCard
                    recent
                    favorites
                }
            }
            .padding(.top, 20)
            .padding(.bottom, 90)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 18) {
            EmptyStateView(icon: "music.note",
                           title: "Здесь пока тихо",
                           text: "Добавьте песни из приложения «Файлы» или из своей медиатеки Apple Music. Файлы также можно просто положить в папку Voilo в «Файлах».")
            HStack(spacing: 12) {
                PillButton(title: "Из Файлов", icon: "folder", action: onAddFiles)
                PillButton(title: "Apple Music", icon: "music.note.list", tonal: true, action: onAddApple)
            }
        }
    }

    private var heroCard: some View {
        let all = library.sorted(.recent)
        return VStack(alignment: .leading, spacing: 18) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Вся музыка")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(c.onPrimaryContainer)
                Text("\(library.tracks.count) \(trackWord(library.tracks.count))")
                    .font(.system(size: 15))
                    .foregroundColor(c.onPrimaryContainer.opacity(0.75))
            }
            HStack(spacing: 12) {
                PillButton(title: "Играть", icon: "play.fill") { player.play(all, at: 0) }
                PillButton(title: "Вперемешку", icon: "shuffle", tonal: true) { player.playShuffled(all) }
            }
        }
        .padding(24)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 32, style: .continuous).fill(c.primaryContainer))
        .padding(.horizontal, 16)
    }

    private var recent: some View {
        let list = Array(library.sorted(.recent).prefix(12))
        return VStack(alignment: .leading, spacing: 12) {
            Text("Недавно добавлено")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(c.onSurface)
                .padding(.horizontal, 20)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 14) {
                    ForEach(Array(list.enumerated()), id: \.element.id) { i, t in
                        Button { player.play(list, at: i) } label: {
                            VStack(alignment: .leading, spacing: 8) {
                                ArtworkView(track: t, size: 148, radius: 28)
                                Text(t.title)
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(c.onSurface)
                                    .lineLimit(1)
                                    .frame(width: 148, alignment: .leading)
                                Text(t.artist)
                                    .font(.system(size: 12))
                                    .foregroundColor(c.onSurfaceVariant)
                                    .lineLimit(1)
                                    .frame(width: 148, alignment: .leading)
                            }
                        }
                        .buttonStyle(PressStyle())
                    }
                }
                .padding(.horizontal, 20)
            }
        }
    }

    @ViewBuilder private var favorites: some View {
        let favs = library.favoriteTracks
        if !favs.isEmpty {
            VStack(alignment: .leading, spacing: 6) {
                Text("Любимое")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(c.onSurface)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 6)
                ForEach(Array(favs.prefix(8).enumerated()), id: \.element.id) { i, t in
                    SongRow(track: t) { player.play(favs, at: i) }
                }
            }
        }
    }

    private func trackWord(_ n: Int) -> String {
        let m10 = n % 10
        let m100 = n % 100
        if m10 == 1 && m100 != 11 { return "трек" }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return "трека" }
        return "треков"
    }
}
