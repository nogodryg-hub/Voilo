import Foundation

// MARK: Сеть

enum Net {
    static func json(_ url: URL, timeout: TimeInterval = 12) async -> Any? {
        var req = URLRequest(url: url)
        req.timeoutInterval = timeout
        req.setValue("Voilo/1.0", forHTTPHeaderField: "User-Agent")
        do {
            let (data, _) = try await URLSession.shared.data(for: req)
            return try JSONSerialization.jsonObject(with: data)
        } catch {
            return nil
        }
    }

    static func url(_ base: String, _ items: [String: String]) -> URL? {
        var c = URLComponents(string: base)
        c?.queryItems = items.map { URLQueryItem(name: $0.key, value: $0.value) }
        return c?.url
    }

    /// Синхронная загрузка небольшого файла (обложки). Вызывать только в фоне.
    static func fetchSync(_ url: URL, timeout: TimeInterval = 8) -> Data? {
        var req = URLRequest(url: url)
        req.timeoutInterval = timeout
        let sem = DispatchSemaphore(value: 0)
        var out: Data?
        URLSession.shared.dataTask(with: req) { data, _, _ in
            out = data
            sem.signal()
        }.resume()
        _ = sem.wait(timeout: .now() + timeout + 1)
        return out
    }
}

// MARK: Модели

struct OnlineTrack: Identifiable, Hashable {
    let id: String
    let title: String
    let artist: String
    let streamURL: String
    let artworkURL: String?
    let duration: Double          // 0 = прямой эфир
    let service: String
    let downloadURL: String?      // только если автор разрешил скачивание

    func asTrack() -> Track {
        Track(id: id, title: title, artist: artist, album: service, duration: duration,
              source: .remote(streamURL), addedAt: Date(), hasArtwork: false, artworkURL: artworkURL)
    }
}

struct Genre: Identifiable, Hashable {
    let id: String
    let title: String
    let icon: String
    let audius: String?
    let tag: String

    static let all: [Genre] = [
        Genre(id: "pop", title: "Поп", icon: "star.fill", audius: "Pop", tag: "pop"),
        Genre(id: "rock", title: "Рок", icon: "flame.fill", audius: "Rock", tag: "rock"),
        Genre(id: "hiphop", title: "Хип-хоп", icon: "mic.fill", audius: "Hip-Hop/Rap", tag: "hiphop"),
        Genre(id: "electronic", title: "Электроника", icon: "bolt.fill", audius: "Electronic", tag: "electronic"),
        Genre(id: "house", title: "Хаус", icon: "headphones", audius: "House", tag: "house"),
        Genre(id: "jazz", title: "Джаз", icon: "music.quarternote.3", audius: "Jazz", tag: "jazz"),
        Genre(id: "classical", title: "Классика", icon: "music.note", audius: "Classical", tag: "classical"),
        Genre(id: "lofi", title: "Lo-Fi", icon: "moon.stars.fill", audius: "Lo-Fi", tag: "lofi"),
        Genre(id: "metal", title: "Метал", icon: "flame", audius: "Metal", tag: "metal"),
        Genre(id: "indie", title: "Инди", icon: "sparkles", audius: "Alternative", tag: "indie"),
        Genre(id: "folk", title: "Фолк", icon: "leaf.fill", audius: "Folk", tag: "folk"),
        Genre(id: "reggae", title: "Реггей", icon: "sun.max.fill", audius: "Reggae", tag: "reggae"),
        Genre(id: "blues", title: "Блюз", icon: "cloud.fill", audius: "Blues", tag: "blues"),
        Genre(id: "rnb", title: "R&B", icon: "heart.fill", audius: "R&B/Soul", tag: "rnb"),
        Genre(id: "ambient", title: "Эмбиент", icon: "waveform", audius: "Ambient", tag: "ambient"),
        Genre(id: "ost", title: "Саундтреки", icon: "film.fill", audius: "Soundtrack", tag: "soundtrack"),
        Genre(id: "anime", title: "Аниме", icon: "sparkles", audius: nil, tag: "anime")
    ]
}

// MARK: Audius (платформа артистов, открытый API)

enum Audius {
    private static var hosts: [String] = []

    private static func resolveHosts() async -> [String] {
        if !hosts.isEmpty { return hosts }
        var list: [String] = []
        if let u = URL(string: "https://api.audius.co"),
           let obj = await Net.json(u) as? [String: Any],
           let arr = obj["data"] as? [String] {
            list = Array(arr.prefix(3))
        }
        list.append("https://discoveryprovider.audius.co")
        hosts = list
        return list
    }

    private static func get(_ path: String, _ query: [String: String]) async -> (host: String, data: [[String: Any]])? {
        var q = query
        q["app_name"] = "Voilo"
        for h in await resolveHosts() {
            guard let u = Net.url(h + path, q),
                  let obj = await Net.json(u) as? [String: Any],
                  let arr = obj["data"] as? [[String: Any]] else { continue }
            return (h, arr)
        }
        return nil
    }

    private static func parse(_ arr: [[String: Any]], host: String) -> [OnlineTrack] {
        arr.compactMap { (d: [String: Any]) -> OnlineTrack? in
            guard let id = d["id"] as? String, let title = d["title"] as? String else { return nil }
            if let streamable = d["is_streamable"] as? Bool, !streamable { return nil }
            let artist = ((d["user"] as? [String: Any])?["name"] as? String) ?? "Audius"
            var art: String?
            if let a = d["artwork"] as? [String: Any] {
                art = (a["480x480"] as? String) ?? (a["150x150"] as? String)
            }
            let dur = (d["duration"] as? NSNumber)?.doubleValue ?? 0
            return OnlineTrack(id: "au-\(id)", title: title, artist: artist,
                               streamURL: "\(host)/v1/tracks/\(id)/stream?app_name=Voilo",
                               artworkURL: art, duration: dur, service: "Audius", downloadURL: nil)
        }
    }

    static func search(_ q: String) async -> [OnlineTrack] {
        guard let r = await get("/v1/tracks/search", ["query": q, "limit": "30"]) else { return [] }
        return parse(r.data, host: r.host)
    }

    static func fetch(genre: Genre?, query: String?) async -> [OnlineTrack] {
        if let q = query, !q.isEmpty { return await search(q) }
        if let g = genre {
            if let a = g.audius,
               let r = await get("/v1/tracks/trending", ["genre": a, "time": "week", "limit": "30"]) {
                return parse(r.data, host: r.host)
            }
            return await search(g.tag)
        }
        return []
    }
}

// MARK: Интернет-радио (каталог Radio Browser)

enum RadioBrowser {
    private static let hosts = ["https://de1.api.radio-browser.info",
                                "https://at1.api.radio-browser.info",
                                "https://nl1.api.radio-browser.info"]

    private static func stations(_ query: [String: String]) async -> [[String: Any]] {
        for h in hosts {
            if let u = Net.url(h + "/json/stations/search", query),
               let arr = await Net.json(u) as? [[String: Any]] {
                return arr
            }
        }
        return []
    }

    private static func map(_ arr: [[String: Any]]) -> [OnlineTrack] {
        arr.compactMap { (d: [String: Any]) -> OnlineTrack? in
            guard let uuid = d["stationuuid"] as? String,
                  let name = d["name"] as? String else { return nil }
            let link = (d["url_resolved"] as? String) ?? (d["url"] as? String) ?? ""
            if link.isEmpty { return nil }
            let tags = ((d["tags"] as? String) ?? "").split(separator: ",").prefix(2).joined(separator: ", ")
            let country = (d["country"] as? String) ?? ""
            let sub = tags.isEmpty ? country : tags
            let fav = d["favicon"] as? String
            return OnlineTrack(id: "rb-\(uuid)",
                               title: name.trimmingCharacters(in: .whitespaces),
                               artist: sub.isEmpty ? "Радио" : sub,
                               streamURL: link,
                               artworkURL: (fav?.isEmpty == false) ? fav : nil,
                               duration: 0, service: "Радио", downloadURL: nil)
        }
    }

    static func fetch(genre: Genre?, query: String?) async -> [OnlineTrack] {
        let base = ["hidebroken": "true", "order": "clickcount", "reverse": "true"]
        if let q = query, !q.isEmpty {
            var byTag = base
            byTag["tag"] = q
            byTag["limit"] = "15"
            var byName = base
            byName["name"] = q
            byName["limit"] = "15"
            let a = map(await stations(byTag))
            let b = map(await stations(byName))
            var seen = Set<String>()
            return (a + b).filter { seen.insert($0.id).inserted }
        }
        if let g = genre {
            var q = base
            q["tag"] = g.tag
            q["limit"] = "25"
            return map(await stations(q))
        }
        return []
    }
}

// MARK: Jamendo (музыка Creative Commons, нужен бесплатный ключ)

enum Jamendo {
    static func fetch(key: String, genre: Genre?, query: String?) async -> [OnlineTrack] {
        var q: [String: String] = ["client_id": key, "format": "json", "limit": "30", "audioformat": "mp32"]
        if let s = query, !s.isEmpty {
            q["search"] = s
            q["order"] = "relevance"
        } else if let g = genre {
            q["tags"] = g.tag
            q["order"] = "popularity_week"
        } else {
            return []
        }
        guard let u = Net.url("https://api.jamendo.com/v3.0/tracks/", q),
              let obj = await Net.json(u) as? [String: Any],
              let arr = obj["results"] as? [[String: Any]] else { return [] }
        return arr.compactMap { (d: [String: Any]) -> OnlineTrack? in
            guard let id = d["id"] as? String,
                  let name = d["name"] as? String,
                  let audio = d["audio"] as? String, !audio.isEmpty else { return nil }
            let allowed = (d["audiodownload_allowed"] as? Bool) ?? false
            let dl = d["audiodownload"] as? String
            let artist = (d["artist_name"] as? String) ?? "Jamendo"
            return OnlineTrack(id: "ja-\(id)", title: name, artist: artist, streamURL: audio,
                               artworkURL: d["image"] as? String,
                               duration: (d["duration"] as? NSNumber)?.doubleValue ?? 0,
                               service: "Jamendo", downloadURL: allowed ? dl : nil)
        }
    }
}

// MARK: Подборка

final class OnlineStore: ObservableObject {
    @Published var results: [OnlineTrack] = []
    @Published var loading = false
    @Published var title = ""
    @Published var error: String? = nil
    @Published var useAudius = true
    @Published var useRadio = true
    @Published var useJamendo = true
    private var ticket = 0

    /// Простые русские слова превращаем в теги каталогов.
    static func normalize(_ q: String) -> String {
        let dict: [String: String] = [
            "вокалоид": "vocaloid", "вокалоиды": "vocaloid", "попса": "pop", "поп": "pop",
            "рок": "rock", "рэп": "rap", "хип-хоп": "hiphop", "джаз": "jazz", "метал": "metal",
            "классика": "classical", "аниме": "anime", "электроника": "electronic", "инди": "indie",
            "фолк": "folk", "блюз": "blues", "реггей": "reggae", "лофай": "lofi", "саундтрек": "soundtrack",
            "эмбиент": "ambient", "хаус": "house", "транс": "trance", "дабстеп": "dubstep",
            "техно": "techno", "кпоп": "kpop", "джпоп": "jpop"
        ]
        return q.lowercased()
            .split(separator: " ")
            .map { dict[String($0)] ?? String($0) }
            .joined(separator: " ")
    }

    private static func fetchOr(_ on: Bool, _ f: @escaping () async -> [OnlineTrack]) async -> [OnlineTrack] {
        if on { return await f() }
        return []
    }

    private static func interleave(_ lists: [[OnlineTrack]]) -> [OnlineTrack] {
        var out: [OnlineTrack] = []
        let longest = lists.map { $0.count }.max() ?? 0
        for i in 0..<longest {
            for l in lists where i < l.count { out.append(l[i]) }
        }
        var seen = Set<String>()
        return out.filter { seen.insert($0.id).inserted }
    }

    func load(title: String, genre: Genre?, query: String?, jamendoKey: String) {
        ticket += 1
        let mine = ticket
        self.title = title
        loading = true
        error = nil
        results = []
        let a = useAudius
        let r = useRadio
        let j = useJamendo && !jamendoKey.isEmpty

        Task {
            async let audius = OnlineStore.fetchOr(a) { await Audius.fetch(genre: genre, query: query) }
            async let radio = OnlineStore.fetchOr(r) { await RadioBrowser.fetch(genre: genre, query: query) }
            async let jamendo = OnlineStore.fetchOr(j) { await Jamendo.fetch(key: jamendoKey, genre: genre, query: query) }
            let merged = OnlineStore.interleave(await [audius, radio, jamendo])
            await MainActor.run {
                guard mine == self.ticket else { return }
                self.results = merged
                self.loading = false
                if merged.isEmpty {
                    self.error = "Ничего не найдено. Проверьте интернет или попробуйте другой запрос."
                }
            }
        }
    }
}
