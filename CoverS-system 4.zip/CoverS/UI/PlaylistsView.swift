import SwiftUI

struct PlaylistsView: View {
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var player: PlayerModel
    @Environment(\.md3) private var c
    @State private var openID: String? = nil

    var body: some View {
        if let id = openID, let p = library.playlists.first(where: { $0.id == id }) {
            PlaylistDetail(playlist: p) { openID = nil }
        } else {
            overview
        }
    }

    private var overview: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                ScreenHeader(title: "Плейлисты", subtitle: "\(library.playlists.count) шт.")
                    .padding(.top, 20)
                HStack {
                    PillButton(title: "Новый плейлист", icon: "plus") {
                        library.newPlaylistSeedTrack = nil
                        library.showNewPlaylist = true
                    }
                }
                .padding(.horizontal, 16)

                if library.playlists.isEmpty {
                    EmptyStateView(icon: "music.note.list",
                                   title: "Плейлистов пока нет",
                                   text: "Создайте плейлист и добавляйте в него песни через меню «⋯» у трека.")
                } else {
                    ForEach(library.playlists) { p in
                        Button { openID = p.id } label: {
                            HStack(spacing: 14) {
                                ArtworkView(track: library.tracks(in: p).first, size: 64, radius: 20)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(p.name)
                                        .font(.system(size: 17, weight: .semibold))
                                        .foregroundColor(c.onSurface)
                                        .lineLimit(1)
                                    Text("\(p.trackIDs.count) треков")
                                        .font(.system(size: 13))
                                        .foregroundColor(c.onSurfaceVariant)
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundColor(c.onSurfaceVariant)
                            }
                            .padding(12)
                            .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(c.surfaceContainerHigh))
                            .padding(.horizontal, 16)
                        }
                        .buttonStyle(PressStyle())
                    }
                }
            }
            .padding(.bottom, 110)
        }
    }
}

struct PlaylistDetail: View {
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var player: PlayerModel
    @Environment(\.md3) private var c
    let playlist: Playlist
    var onBack: () -> Void
    @State private var renaming = false
    @State private var newName = ""

    var body: some View {
        let list = library.tracks(in: playlist)
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    IconButton(system: "chevron.left", size: 44, filled: true, action: onBack)
                    Spacer()
                    Menu {
                        Button { newName = playlist.name; renaming = true } label: {
                            Label("Переименовать", systemImage: "pencil")
                        }
                        Button(role: .destructive) {
                            library.deletePlaylist(playlist.id)
                            onBack()
                        } label: { Label("Удалить плейлист", systemImage: "trash") }
                    } label: {
                        Image(systemName: "ellipsis")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(c.onSecondaryContainer)
                            .frame(width: 44, height: 44)
                            .background(Circle().fill(c.secondaryContainer))
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 16)

                ScreenHeader(title: playlist.name, subtitle: "\(list.count) треков")

                if renaming {
                    HStack(spacing: 10) {
                        TextField("Название", text: $newName)
                            .padding(.horizontal, 16)
                            .frame(height: 48)
                            .background(Capsule().fill(c.surfaceContainerHigh))
                            .foregroundColor(c.onSurface)
                        PillButton(title: "OK") {
                            library.rename(playlist.id, to: newName)
                            renaming = false
                        }
                    }
                    .padding(.horizontal, 16)
                }

                if !list.isEmpty {
                    HStack(spacing: 10) {
                        PillButton(title: "Играть", icon: "play.fill") { player.play(list, at: 0) }
                        PillButton(title: "Вперемешку", icon: "shuffle", tonal: true) { player.playShuffled(list) }
                    }
                    .padding(.horizontal, 16)
                } else {
                    EmptyStateView(icon: "music.note.list",
                                   title: "Плейлист пуст",
                                   text: "Добавьте песни через меню «⋯» у трека.")
                }

                ForEach(Array(list.enumerated()), id: \.element.id) { i, t in
                    SongRow(track: t, onPlay: { player.play(list, at: i) },
                            onRemove: { library.remove(t.id, from: playlist.id) })
                }
            }
            .padding(.bottom, 110)
        }
    }
}

struct NewPlaylistSheet: View {
    @EnvironmentObject var library: LibraryStore
    @Environment(\.md3) private var c
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""

    var body: some View {
        ZStack {
            c.surface.ignoresSafeArea()
            VStack(alignment: .leading, spacing: 20) {
                Text("Новый плейлист")
                    .font(.system(size: 26, weight: .bold))
                    .foregroundColor(c.onSurface)
                TextField("Название", text: $name)
                    .padding(.horizontal, 18)
                    .frame(height: 56)
                    .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(c.surfaceContainerHigh))
                    .foregroundColor(c.onSurface)
                HStack(spacing: 12) {
                    Spacer()
                    PillButton(title: "Отмена", tonal: true) { dismiss() }
                    PillButton(title: "Создать") {
                        let p = library.createPlaylist(name)
                        if let tid = library.newPlaylistSeedTrack {
                            library.add(tid, to: p.id)
                        }
                        library.newPlaylistSeedTrack = nil
                        dismiss()
                    }
                }
                Spacer()
            }
            .padding(24)
        }
    }
}
