import Foundation
import AVFoundation
import MediaPlayer
import UIKit

enum Paths {
    static var docs: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    static var videos: URL {
        ensure(docs.appendingPathComponent("Videos", isDirectory: true))
    }

    static var music: URL {
        ensure(docs.appendingPathComponent("Music", isDirectory: true))
    }

    static var support: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return ensure(base.appendingPathComponent("Sonora", isDirectory: true))
    }

    static var artwork: URL {
        ensure(support.appendingPathComponent("Artwork", isDirectory: true))
    }

    static var libraryFile: URL {
        support.appendingPathComponent("library.json")
    }

    private static func ensure(_ url: URL) -> URL {
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }
}

final class LibraryStore: ObservableObject {
    @Published var tracks: [Track] = [] { didSet { sortCache.removeAll() } }
    @Published var playlists: [Playlist] = []
    @Published var favorites: Set<String> = []
    @Published var importing = false
    @Published var message: String? = nil
    @Published var showNewPlaylist = false
    var newPlaylistSeedTrack: String? = nil

    private struct Snapshot: Codable {
        var tracks: [Track]
        var playlists: [Playlist]
        var favorites: [String]
    }

    private static let audioExts: Set<String> = ["mp3", "m4a", "aac", "wav", "aif", "aiff", "caf", "flac", "alac", "mp4"]
    private let io = DispatchQueue(label: "app.sonora.io")
    private var sortCache: [SortMode: [Track]] = [:]

    init() {
        load()
        scanDocumentsDrop()
    }

    // MARK: Сохранение

    private func load() {
        guard let data = try? Data(contentsOf: Paths.libraryFile),
              let snap = try? JSONDecoder().decode(Snapshot.self, from: data) else { return }
        tracks = snap.tracks
        playlists = snap.playlists
        favorites = Set(snap.favorites)
    }

    func save() {
        let snap = Snapshot(tracks: tracks, playlists: playlists, favorites: Array(favorites))
        io.async {
            if let data = try? JSONEncoder().encode(snap) {
                try? data.write(to: Paths.libraryFile, options: .atomic)
            }
        }
    }

    // MARK: Файлы

    func importFiles(_ urls: [URL], onDone: ((Int) -> Void)? = nil) {
        importing = true
        io.async { [weak self] in
            var added: [Track] = []
            for url in urls {
                let scoped = url.startAccessingSecurityScopedResource()
                if let t = LibraryStore.ingest(url, move: false) { added.append(t) }
                if scoped { url.stopAccessingSecurityScopedResource() }
            }
            DispatchQueue.main.async {
                self?.finishImport(added, manual: true)
                onDone?(added.count)
            }
        }
    }

    /// Файлы, положенные в папку приложения через приложение «Файлы», подхватываются автоматически.
    func scanDocumentsDrop() {
        guard let items = try? FileManager.default.contentsOfDirectory(at: Paths.docs,
                                                                       includingPropertiesForKeys: nil,
                                                                       options: [.skipsHiddenFiles]) else { return }
        let files = items.filter { LibraryStore.audioExts.contains($0.pathExtension.lowercased()) }
        guard !files.isEmpty else { return }
        importing = true
        io.async { [weak self] in
            var added: [Track] = []
            for f in files {
                if let t = LibraryStore.ingest(f, move: true) { added.append(t) }
            }
            DispatchQueue.main.async {
                self?.finishImport(added, manual: false)
            }
        }
    }

    private func finishImport(_ added: [Track], manual: Bool) {
        tracks.append(contentsOf: added)
        importing = false
        if !added.isEmpty {
            message = "Добавлено треков: \(added.count)"
        } else if manual {
            message = "Не удалось добавить файлы"
        }
        save()
    }

    private static func nonEmpty(_ s: String?) -> String? {
        guard let s = s?.trimmingCharacters(in: .whitespacesAndNewlines), !s.isEmpty else { return nil }
        return s
    }

    static func ingest(_ src: URL, move: Bool) -> Track? {
        let fm = FileManager.default
        let id = UUID().uuidString
        let ext = src.pathExtension.isEmpty ? "m4a" : src.pathExtension.lowercased()
        let dest = Paths.music.appendingPathComponent(id + "." + ext)
        do {
            if move {
                try fm.moveItem(at: src, to: dest)
            } else {
                try fm.copyItem(at: src, to: dest)
            }
        } catch {
            return nil
        }

        let asset = AVURLAsset(url: dest)
        guard asset.isPlayable else {
            try? fm.removeItem(at: dest)
            return nil
        }

        var title: String?
        var artist: String?
        var album: String?
        var art: Data?
        for item in asset.commonMetadata {
            guard let key = item.commonKey else { continue }
            switch key {
            case .commonKeyTitle: title = item.stringValue
            case .commonKeyArtist: artist = item.stringValue
            case .commonKeyAlbumName: album = item.stringValue
            case .commonKeyArtwork: art = item.dataValue
            default: break
            }
        }

        let secs = CMTimeGetSeconds(asset.duration)
        let duration = secs.isFinite ? secs : 0

        var hasArt = false
        if let d = art, let img = UIImage(data: d) {
            let small = img.scaled(maxSide: 900)
            if let jpg = small.jpegData(compressionQuality: 0.85) {
                try? jpg.write(to: Paths.artwork.appendingPathComponent(id + ".jpg"))
                hasArt = true
            }
        }

        let fallback = src.deletingPathExtension().lastPathComponent
        return Track(id: id,
                     title: nonEmpty(title) ?? fallback,
                     artist: nonEmpty(artist) ?? "Неизвестный исполнитель",
                     album: nonEmpty(album) ?? "",
                     duration: duration,
                     source: .file(id + "." + ext),
                     addedAt: Date(),
                     hasArtwork: hasArt)
    }

    // MARK: Apple Music

    static func makeTrack(_ a: AMSong) -> Track {
        Track(id: "am-\(a.id)",
              title: a.title,
              artist: a.artist,
              album: a.album,
              duration: a.duration,
              source: .apple(a.id),
              addedAt: a.added,
              hasArtwork: true)
    }

    func importApple(_ songs: [AMSong]) {
        let existing = Set(tracks.map { $0.id })
        let fresh = songs.map { LibraryStore.makeTrack($0) }.filter { !existing.contains($0.id) }
        guard !fresh.isEmpty else {
            message = "Эти песни уже добавлены"
            return
        }
        tracks.append(contentsOf: fresh)
        message = "Добавлено из Apple Music: \(fresh.count)"
        save()
    }

    func importApplePlaylist(_ p: AMPlaylist, all songs: [AMSong]) {
        let map = Dictionary(songs.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        let chosen = p.songIDs.compactMap { map[$0] }
        let existing = Set(tracks.map { $0.id })
        let fresh = chosen.map { LibraryStore.makeTrack($0) }.filter { !existing.contains($0.id) }
        tracks.append(contentsOf: fresh)
        playlists.append(Playlist(id: UUID().uuidString, name: p.name, trackIDs: chosen.map { "am-\($0.id)" }))
        message = "Плейлист «\(p.name)» добавлен"
        save()
    }

    // MARK: Треки

    func delete(_ track: Track) {
        if case .file(let name) = track.source {
            try? FileManager.default.removeItem(at: Paths.music.appendingPathComponent(name))
        }
        try? FileManager.default.removeItem(at: Paths.artwork.appendingPathComponent(track.id + ".jpg"))
        tracks.removeAll { $0.id == track.id }
        favorites.remove(track.id)
        for i in playlists.indices {
            playlists[i].trackIDs.removeAll { $0 == track.id }
        }
        save()
    }

    func addRemote(_ t: Track) {
        if tracks.contains(where: { $0.id == t.id }) {
            message = "Уже в библиотеке"
            return
        }
        tracks.append(t)
        message = "Добавлено в библиотеку"
        save()
    }

    func toggleFavorite(_ id: String) {
        if favorites.contains(id) { favorites.remove(id) } else { favorites.insert(id) }
        save()
    }

    func sorted(_ mode: SortMode) -> [Track] {
        if let hit = sortCache[mode] { return hit }
        let result: [Track]
        switch mode {
        case .recent:
            result = tracks.sorted { $0.addedAt > $1.addedAt }
        case .title:
            result = tracks.sorted { $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending }
        case .artist:
            result = tracks.sorted {
                let c = $0.artist.localizedCaseInsensitiveCompare($1.artist)
                if c == .orderedSame { return $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending }
                return c == .orderedAscending
            }
        }
        sortCache[mode] = result
        return result
    }

    var favoriteTracks: [Track] {
        tracks.filter { favorites.contains($0.id) }
    }

    // MARK: Плейлисты

    @discardableResult
    func createPlaylist(_ name: String) -> Playlist {
        let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let p = Playlist(id: UUID().uuidString, name: n.isEmpty ? "Новый плейлист" : n, trackIDs: [])
        playlists.append(p)
        save()
        return p
    }

    func add(_ trackID: String, to playlistID: String) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        if !playlists[i].trackIDs.contains(trackID) {
            playlists[i].trackIDs.append(trackID)
            message = "Добавлено в «\(playlists[i].name)»"
            save()
        } else {
            message = "Уже в «\(playlists[i].name)»"
        }
    }

    func remove(_ trackID: String, from playlistID: String) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        playlists[i].trackIDs.removeAll { $0 == trackID }
        save()
    }

    func rename(_ playlistID: String, to name: String) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if !n.isEmpty { playlists[i].name = n; save() }
    }

    func deletePlaylist(_ id: String) {
        playlists.removeAll { $0.id == id }
        save()
    }

    func tracks(in playlist: Playlist) -> [Track] {
        let map = Dictionary(tracks.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        return playlist.trackIDs.compactMap { map[$0] }
    }
}
